<div class="card bg-success text-white h-100">
    <div class="card-header d-flex justify-content-around">
    <?php echo e($comment->user->name); ?> - <?php echo e($comment->user->role->role); ?>

    <form action="<?php echo e(route('moderator.comments.delete',$comment)); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
    <button class="btn-close" aria-label="Close"></button>
    </form>
    </div>
    <div class="card-body d-flex flex-column justify-content-between text-center">
        <p class="card-title">Комментарий:</p>
        <h6 class="card-text"><?php echo e($comment->short_comment); ?></h6>
    </div>
    <div class="card-footer">
        <div class="text-center"><?php echo e($comment->date_comment_humans); ?></div>
    </div>
    <div class="card-footer">
        <form action="<?php echo e(route('moderator.comments.post',$comment)); ?>" method="post" class="d-flex justify-content-between">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PATCH'); ?>
            <button class="btn text-decoration-none text-white p-0"><?php echo e(!$comment->posted?"Опубликовать":"Заблокировать"); ?></button>
            <a href="<?php echo e(route('moderator.comments.show',$comment)); ?>" class="text-decoration-none text-white">Подробно</a>
        </form>
    </div>
</div>
<?php /**PATH C:\OpenServer\domains\goldengirls\resources\views/inc/moderator/comment.blade.php ENDPATH**/ ?>