<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Админ панель</h1>

    </div>

    <div>
        <?php echo $__env->yieldContent('content'); ?>
    </div>
</main>
</div>
</div>
<?php /**PATH /home/l/lomtsols/lomtsols.beget.tech/public_html/resources/views/inc/admin/main.blade.php ENDPATH**/ ?>