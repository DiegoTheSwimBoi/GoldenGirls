

<?php $__env->startSection('title',"Комментарии"); ?>

<?php $__env->startSection("content"); ?>
        <div class="container mt-5">
            <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-lg-3 g-3">

        
            <div>
                <p><?php echo e($comment->user->name); ?> - <?php echo e($comment->user->role->role); ?></p>
<div class="d-flex justify-content-around">
                <form action="<?php echo e(route('moderator.comments.delete',$comment)); ?>" method="post">

                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button class="btn-close" aria-label="Close"></button>
                </form>
                <form action="<?php echo e(route('moderator.comments.post',$comment)); ?>" method="post" class="d-flex justify-content-between">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PATCH'); ?>
            <button class="btn text-decoration-none p-0"><?php echo e(!$comment->posted?"Опубликовать":"Заблокировать"); ?></button>
            <a href="<?php echo e(route('moderator.comments.show',$comment)); ?>" class="text-decoration-none text-white">Подробно</a>
            </form>
</div>
                <div class="card-body">
                    <p><?php echo e($comment->comment); ?></p>
                </div>
                
            </div>
        
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.moderator', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\goldengirls\resources\views/moderator/comment-show.blade.php ENDPATH**/ ?>