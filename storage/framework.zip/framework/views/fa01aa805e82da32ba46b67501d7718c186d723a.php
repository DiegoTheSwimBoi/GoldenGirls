<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?php echo $__env->yieldContent('title'); ?></title>
    <!--Styles-->
    <link href="<?php echo e(asset('/css/bootstrap.min.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(asset('/css/style.css')); ?>" rel="stylesheet">
    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">
</head>
<body class="antialiased">

<div class="container">
    <?php echo $__env->yieldContent('content'); ?>
</div>

<script src="<?php echo e(asset('/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/WorkWithFile.js')); ?>"></script>
</body>

</html><?php /**PATH C:\OpenServer\domains\goldengirls\resources\views/layouts/login.blade.php ENDPATH**/ ?>