<?php $__env->startSection("title",$post['title']); ?>


<?php $__env->startSection("content"); ?>
    <div class="container-body text-light mt-5">

        <div class="logo"></div>

        <div class="container text-center">
            <div class="row">
                <a href="<?php echo e(route('welcome')); ?>" class="col-md-3 text-decoration-none hover pink">Golden Girls</a>
                <?php $__currentLoopData = $data['header']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$nav): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route($key)); ?>" class="col-md-2 text-decoration-none hover pink"><?php echo e($nav); ?></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <div class="p-md-5">
            <hr class="logo-line">
        </div>
        <div class="container text-center">
            <div>
                <img src="<?php echo e(asset('/storage/characters/view/creators/photo.png')); ?>" class="w-50" style="transform: rotate(2.5deg); border: 3px solid white;" alt="Golden Girls">
                <h3 class="mt-5"><?php echo e($post['message']); ?></h3>
            </div>
            <div class="mt-5 row d-flex">
                <div class='content'>
                    <?php $__currentLoopData = $post['content']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class='mt-4'>
                        <p class='text-start' style="font-size: large;"><?php echo e($content); ?></p>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="mt-5">
                    <img src="<?php echo e(asset('/storage/characters/view/creators/photo2.png')); ?>" class="w-50" style="transform: rotate(3deg); border: 3px solid white;" alt="Golden Girls">
                </div>
            </div>
        </div>

        <div class="mt-5">
            <?php echo $__env->make("inc.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/l/lomtsols/lomtsols.beget.tech/public_html/resources/views/creators.blade.php ENDPATH**/ ?>