


<?php $__env->startSection("title","hello blade php"); ?>


<?php $__env->startSection("content"); ?>
    <div>
        <p id="countUsers">Кол-во пользователей: <?php echo e(count($users)); ?></p>
    </div>
    <ul class="list-group" id="list">
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="list-group-item">
        <div class="d-flex justify-content-between">
             <div class="d-flex"><p><?php echo e($user->name); ?></p>- <?php echo e($user->role->role); ?>  -
                  <p><?php echo e(count($user->comments)); ?> комментариев</p>
             </div>
             <form action="<?php echo e(route('moderator.banned',$user)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PATCH'); ?>
             <button class="btn btn-danger"><?php echo e($user->banned?"Разблокировать":"Заблокировать"); ?></button>
             </form> 
         </div>
        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.moderator', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\goldengirls\resources\views/moderator/users.blade.php ENDPATH**/ ?>