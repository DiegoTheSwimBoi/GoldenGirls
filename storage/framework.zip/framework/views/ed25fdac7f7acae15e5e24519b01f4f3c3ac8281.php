<?php $__env->startSection("title","Пользователь"); ?>
<?php $__env->startSection("content"); ?>
<div class="card mb-3 mt-5 p-5">
    <p><?php echo e($user->name); ?></p>
    <div>
    <p>Комментарие, которые вы написали:  <?php echo e($user->comments->count()); ?></p>
    <hr>
    <ul class="list-group">
    <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="list-group-item">
        <div class="d-flex justify-content-between">
             <div class="d-flex gap-3">
             <p class="<?php echo e($comment->banned?'text-success':'text-danger'); ?>"><?php echo e($comment->banned?"Опубликован":"Не опубликован"); ?></p>
             <p><?php echo e($user->name); ?></p>- <?php echo e($comment->short_comment); ?>

             </div>
             <form action="<?php echo e(route('comment.delete',$comment)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
             <button class="btn btn-danger">Удалить</button>
             </form>
         </div>
        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/l/lomtsols/lomtsols.beget.tech/public_html/resources/views/users/comments.blade.php ENDPATH**/ ?>