<?php if(auth()->guard()->guest()): ?>
    <div class="text-info text-center"><a href="<?php echo e(route('auth.index')); ?>"
                                          class="text-decoration-none hover pink"><?php echo e($data['login']); ?></a></div>
<?php endif; ?>

<div class=" p-5  mb-5">
    <?php if(auth()->guard()->check()): ?>
        <div class="text-info text-center">
            <a href="<?php echo e(route('user')); ?>" class="text-decoration-none hover text-warning"><?php echo e($data['user']['login']); ?></a>
        </div>
    <?php endif; ?>
</div>
<div class="p-5">
    <hr>
    <div>
        <div class="container text-center">
            <div class="row d-flex">
                <?php $__currentLoopData = $data['header']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$nav): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e($key); ?>" class="col-md-3 mb-5 text-decoration-none hover pink"><?php echo e($nav); ?></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <div class="d-flex justify-content-between flex-wrap mt-5">
            <a href="<?php echo e(route('welcome')); ?>" class="text-decoration-none hover pink">Golden Girls</a>
            <?php $__currentLoopData = $data['footer']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $text): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <p class="mb-5"><?php echo e($text); ?></p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route('about')); ?>" class="text-decoration-none text-white"><?php echo e($data['more-about']['about']); ?></a>
        </div>
    </div>
</div>
<?php /**PATH C:\OpenServer\domains\goldengirls\resources\views/inc/footer.blade.php ENDPATH**/ ?>