<?php $__env->startSection("title","Сохранение в json"); ?>
<?php $__env->startSection("content"); ?>
    <h2>Сохранить данные в формате json</h2>
    <div>
        <a class="btn btn-danger">Сохранить Пользователей</a>
        <a class="btn btn-success">Сохранить Посты</a>
        <a class="btn btn-primary">Сохранить Категории</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\goldengirls\resources\views/admin/savefile.blade.php ENDPATH**/ ?>