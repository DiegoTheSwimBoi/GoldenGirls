<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?php echo $__env->yieldContent('title'); ?></title>
    <!--Styles-->
    <link rel="shortcut icon" href="<?php echo e(asset('/storage/logo/icon.ico')); ?>" type="image/x-icon">
    <link href="<?php echo e(asset('/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('/css/style.css')); ?>" rel="stylesheet">
    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        body{
            background-color: #FABCFF;
        }

        .border-rectangle{
            background: #af83b2;
        }

        .pink-rectangle{
            background: #fcd6ff;
        }
    </style>
    <?php if(auth()->guard()->check()): ?>
        <style>
            body{
                background-color: #fffabc;
            }

            .border-rectangle{
                background: #ccc896;
            }

            .pink-rectangle{
                background: #fffbd0;
            }

        </style>
    <?php endif; ?>
</head>
<body class="antialiased">

<div class="cont">
    <?php echo $__env->yieldContent('content'); ?>
</div>

<script src="<?php echo e(asset('/js/bootstrap.bundle.min.js')); ?>"></script>
<?php echo $__env->yieldContent('scripts'); ?>
</body>

</html>
<?php /**PATH C:\OpenServer\domains\goldengirls\resources\views/layouts/main.blade.php ENDPATH**/ ?>