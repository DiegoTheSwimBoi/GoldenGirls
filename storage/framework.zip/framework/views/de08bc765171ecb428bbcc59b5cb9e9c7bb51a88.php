<?php $__env->startSection("title","Главная"); ?>
<?php $__env->startSection("content"); ?>
<div><a class="btn btn-outline-info" href="<?php echo e(route('admin.save.post')); ?>">Сохранить посты</a></div>
<div class="mt-2">
<ul class="list-group" id="list">
<?php if($posts->count()>0): ?>
    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <li class="list-group-item"><div class="d-flex justify-content-between">
             <div class="d-flex">
                  <p><?php echo e($post->title); ?> : <?php echo e($post->country->flag); ?></p>
             </div>
             <div class="d-flex gap-3 justify-content-between">
             <a href="<?php echo e(route('admin.post.show',$post)); ?>"  class="btn btn-primary">Подробно</a>
             <a href="<?php echo e(route('admin.post.edit',$post)); ?>"  class="btn btn-secondary">Редактировать</a>
             <div>
            <form action="<?php echo e(route('admin.post.destroy',$post->id)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button class="btn btn-danger">Удалить</button>
            </form>
            </div>
            </div>
         </div></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
<li class="list-group-item"><div class="d-flex justify-content-between">
             <div class="d-flex">
                  <p>Список статей пуст по этой категории</p>
             </div>
             <a href="<?php echo e(route('admin.post.add')); ?>" id='basket' class="btn btn-info">Добавить</a>
         </div></li>
<?php endif; ?>
    </ul>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\goldengirls\resources\views/post/index.blade.php ENDPATH**/ ?>