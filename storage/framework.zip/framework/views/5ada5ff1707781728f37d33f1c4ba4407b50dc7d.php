<?php $__env->startSection("title","Пользователь"); ?>
<?php $__env->startSection("content"); ?>
    <div class="card mb-3 mt-5 p-5">
        <form method="post" action="<?php echo e(route('user.update')); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field("PATCH"); ?>
        <div class="input-group mb-3">
            <input type="text" class="form-control" name="name" value="<?php echo e($user->name); ?>" placeholder="<?php echo e($data['user']['setting']['name']); ?>" aria-label="Username" aria-describedby="basic-addon1">
            <input type="text" value="<?php echo e($user->name); ?>"  class="form-control" readonly>
        </div>
            <div class="input-group mb-3">
                <input type="text" class="form-control" name="email" value="<?php echo e($user->email); ?>" placeholder="@email" aria-label="Username" aria-describedby="basic-addon1">
                <input type="text" name="email_old" value="<?php echo e($user->email); ?>" class="form-control" readonly>
            </div>
        <div class="input-group mb-3">
            <input type="password" name="password" class="form-control" placeholder="<?php echo e($data['user']['setting']['newPassword']); ?>" aria-label="Username" aria-describedby="basic-addon1">
        </div>
        <div class="input-group mb-3">
            <input type="password" class="form-control" name="password_confirmation" placeholder="<?php echo e($data['user']['setting']['oldPassword']); ?>" aria-label="Username" aria-describedby="basic-addon1">
        </div>

        <button class="btn btn-dark w-100"><?php echo e($data['user']['setting']['update']); ?></button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\goldengirls\resources\views/users/settings.blade.php ENDPATH**/ ?>