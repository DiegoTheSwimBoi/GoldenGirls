


<?php $__env->startSection("title","Posts - your magical"); ?>
<?php $__env->startSection("content"); ?>
<h1>Some</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\goldengirls\resources\views/some.blade.php ENDPATH**/ ?>