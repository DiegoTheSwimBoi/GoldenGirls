<div class="text-end">
    <div class="p-5" style="font-size: 20px;">
        <form id="like" method="post">
            <?php echo csrf_field(); ?>
            <?php echo method_field("PATCH"); ?>
            <button type="submit" id="<?php echo e(Auth::id()); ?>" class="btn like <?php echo e($post->likes[0]->like_class); ?>"
                    style="font-size: 21px;" <?php if(auth()->guard()->guest()): ?> disabled <?php endif; ?>></button>
            <span id="count"><?php echo e($post->likes[0]->likes); ?></span>
        </form>
    </div>
</div>
<?php if(auth()->guard()->guest()): ?>
    <div class="text-info text-center"><a href="<?php echo e(route('auth.index')); ?>"
                                          class="text-decoration-none hover pink"><?php echo e($data['login']); ?></a></div>
<?php endif; ?>

<div class=" p-5  mb-5">
    <?php if(auth()->guard()->check()): ?>
        <div class="text-info text-center">
            <a href="<?php echo e(route('user')); ?>" class="text-decoration-none hover text-warning"><?php echo e($data['user']['login']); ?></a>
        </div>
    <?php endif; ?>
    <?php echo $__env->make('inc.comments', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<div class="p-5">
    <hr>
    <div>
        <div class="container text-center">
            <div class="row d-flex">
                <?php $__currentLoopData = $data['header']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$nav): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e($key); ?>" class="col-md-3 text-decoration-none hover pink"><?php echo e($nav); ?></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <div class="d-flex justify-content-between flex-wrap mt-5">
            <a href="<?php echo e(route('welcome')); ?>" class="text-decoration-none text-white">Golden Girls</a>            <?php $__currentLoopData = $data['footer']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $text): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <p><?php echo e($text); ?></p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route('about')); ?>" class="text-decoration-none text-white"></a>
        </div>
    </div>
</div>
<?php /**PATH /home/l/lomtsols/lomtsols.beget.tech/public_html/resources/views/inc/post-footer.blade.php ENDPATH**/ ?>