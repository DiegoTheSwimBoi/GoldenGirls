<?php $__env->startSection("title","Пользователь"); ?>
<?php $__env->startSection("content"); ?>
<div class="card mb-3 mt-5 p-5">
    <?php echo $__env->make("inc.error", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <p><?php echo e($user->name); ?></p>
    <div>
    <p><?php echo e($data['user']['comments-posted']); ?>  <?php echo e($user->comments->count()); ?></p>
    <div class="progress">
  <div class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar" aria-valuenow="<?php echo e($user->comments->count()); ?>" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo e($user->comments->count()); ?>%"></div>
</div>
</div>
<div class="mt-5"><p><?php echo e($data['user']['posts-liked']); ?>  <?php echo e($like); ?></p>
    <div class="progress">
  <div class="progress-bar progress-bar-striped progress-bar-animated bg-danger" role="progressbar" aria-valuenow="<?php echo e($like); ?>" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo e($like); ?>%"></div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/l/lomtsols/lomtsols.beget.tech/public_html/resources/views/users/index.blade.php ENDPATH**/ ?>