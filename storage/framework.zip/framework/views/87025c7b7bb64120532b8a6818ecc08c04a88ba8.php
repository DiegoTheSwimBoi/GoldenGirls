<div class="modal fade" id="modalDestroy" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body p-0 w-100">
                <?php echo $__env->make('inc.slider', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /home/l/lomtsols/lomtsols.beget.tech/public_html/resources/views/inc/modal_gallery.blade.php ENDPATH**/ ?>