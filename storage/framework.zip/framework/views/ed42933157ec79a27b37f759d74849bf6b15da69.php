<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link rel="shortcut icon" href="<?php echo e(asset('/storage/logo/icon.ico')); ?>" type="image/x-icon">
    <!--Styles-->
    <link href="<?php echo e(asset('/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('/css/styles.css')); ?>" rel="stylesheet">
    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">
</head>
<body class="antialiased">
        <?php echo $__env->make('inc.admin.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container-fluid">
    <div class="row">
        <?php echo $__env->make('inc.admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('inc.admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>

<script src="<?php echo e(asset('/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/WorkWithFile.js')); ?>"></script>
<?php echo $__env->yieldPushContent('child-scripts'); ?>
</body>

</html>
<?php /**PATH /home/l/lomtsols/lomtsols.beget.tech/public_html/resources/views/layouts/admin.blade.php ENDPATH**/ ?>