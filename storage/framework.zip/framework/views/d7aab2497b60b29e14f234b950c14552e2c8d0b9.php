<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2"> </h1>
        <div class="btn-toolbar mb-2 mb-md-0">
            <div class="btn-group me-2 p-2">
                <a  href="javascript:history.back()" class="btn btn-sm btn-outline-secondary"><?php echo e($data['back']); ?></a>
                <a  href="<?php echo e(route('welcome')); ?>" class="btn btn-sm btn-outline-secondary"><?php echo e($data['main']); ?></a>
            </div>


        </div>

    </div>

    <div>
        <?php echo $__env->yieldContent('content'); ?>
    </div>
</main>
</div>
</div>
<?php /**PATH /home/l/lomtsols/lomtsols.beget.tech/public_html/resources/views/inc/user/main.blade.php ENDPATH**/ ?>