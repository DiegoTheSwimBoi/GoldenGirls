<?php $__env->startSection('title', 'user-edit'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2><?php echo e($user->full_name); ?></h2>
        <form id="userEdit" method="post">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PATCH'); ?>
            <div class="input-group mb-4">
                <span class="input-group-text" id="inputGroup-sizing-default"><?php echo e($user->name); ?></span>
                <select id="selectRole" class="form-select" aria-label=".form-select-sm example">
                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($role->id); ?>" <?php echo e($role->id==$user->role_id?'selected':''); ?>><?php echo e($role->role); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <label class="input-group-text" for="selectRole"><button type="submit" class="btn btn-sm">Обновить</button></label>
            </div>
                <div class="" id="sucess-box" role="alert">
                   <p id="sucess-text"></p> 
                </div>
        </form>
        <form method="POST" action="<?php echo e(route('admin.banned',$user)); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PATCH'); ?>
            <button class="btn btn-primary"><?php echo e($user->banned?"Разблокировать":"Заблокировать"); ?></button>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('child-scripts'); ?>
    <script>

        async function updateUser(route, data, _token) {
            document.getElementById('sucess-box').className="";
            document.getElementById('sucess-text').innerHTML="";
            let response = await fetch(route, {
                method: 'PATCH',
                headers: {
                    'Content-Type': 'application/json; charset=UTF-8',
                },
                body: JSON.stringify({data, _token}),
            });
            return await response.json();
        }

        document.getElementById('userEdit').addEventListener('submit', async (e) => {
            //запрет на работу по умолчанию
            e.preventDefault();
            let data = await updateUser("<?php echo e(route('admin.usersupdate', $user)); ?>", selectRole.value, "<?php echo e(csrf_token()); ?>");
            document.getElementById('sucess-text').innerHTML="Обновление произошло удачно.";
            document.getElementById('sucess-box').className=" alert alert-success alert-dismissible fade show";
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/l/lomtsols/lomtsols.beget.tech/public_html/resources/views/admin/userEdit.blade.php ENDPATH**/ ?>