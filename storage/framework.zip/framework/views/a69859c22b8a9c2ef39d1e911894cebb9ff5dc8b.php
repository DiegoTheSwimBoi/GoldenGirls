<?php $__env->startSection("title","Главная"); ?>
<?php $__env->startSection("content"); ?>
<div class="card bg-dark text-white mb-3 mt-5 p-5">
    <div>
        <h3><?php echo e($post->title); ?></h3>
        <hr>
    </div>
    <div>
        <div>
            <?php echo $post->content; ?>

        </div>
        <hr>
        <div>
            Количество лайков <?php echo e($likes->likes); ?>

        </div>
    </div>
    <div>
        <div class="d-flex justify-content-around">
        <?php if(!empty($contents)): ?>
            <?php $__currentLoopData = $contents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($content->type=="image"): ?>
                <div><img src="<?php echo e($content->image_full); ?>" height="320" width="280"/></div>
                <?php endif; ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            
        <?php endif; ?>

        </div>
        <div class="text-center">
        <?php if(!empty($contents)): ?>
        <?php $__currentLoopData = $contents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($content->type=="video"): ?>
                <div><video width="320" height="240" controls="controls"><source src="<?php echo e($content->image_full); ?>" type='video/mp4'></video></div>
                <?php endif; ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/l/lomtsols/lomtsols.beget.tech/public_html/resources/views/post/show.blade.php ENDPATH**/ ?>