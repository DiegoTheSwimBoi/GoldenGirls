<div class="logo"></div>
<div class="container text-center">
    <div class="row">
        <?php $__currentLoopData = $data['header']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$nav): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route($key)); ?>" class="col-md-3 mb-5 text-decoration-none hover pink"><?php echo e($nav); ?></a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php if(auth()->guard()->check()): ?>
            <a href="<?php echo e(route('user')); ?>" class="col-md-6 mt-5 text-decoration-none hover text-warning"><?php echo e(Auth()->user()->name); ?></a>
            <a href="<?php echo e(route('logout')); ?>" class="col-md-6 mt-5 text-decoration-none hover pink"><?php echo e($data['logout']); ?></a>
        <?php endif; ?>
    </div>
<?php /**PATH /home/l/lomtsols/lomtsols.beget.tech/public_html/resources/views/inc/menu.blade.php ENDPATH**/ ?>