<?php $__env->startSection("title","hello blade php"); ?>


<?php $__env->startSection("content"); ?>
    <?php if(isset($roles) and !empty($roles)): ?>
        <div>
            <label for="roles">Выберите роль (сортировка по пользователям)</label>
            <select class="form-control" id="roles" style="width: 25%">
                <option value="0">Все пользователи</option>
                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($role->id); ?>" name="role"><?php echo e($role->role); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    <?php endif; ?>

    <div class="mt-3"><a class="btn btn-outline-info" href="<?php echo e(route('admin.save.admin')); ?>">Сохранить данные администратора</a></div>
    <hr>
    <div>
        <p id="countUsers"></p>
    </div>
    <ul class="list-group" id="list"></ul>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('child-scripts'); ?>
    <script src="<?php echo e(asset('/js/fetchGet.js')); ?>"></script>
    <script src="<?php echo e(asset('/js/writeUserLine.js')); ?>"></script>
    <script>
        let flagName, flagPost = true;
        let users = [];
        console.log('gg');

        document.getElementById('roles').addEventListener('change', async (e) => {
            //console.log(e.target.value);
            users = await countFilteredUsers(e.target.value);
            countUsers(users);
        });


        async function getUsersFilter(role) {
            let response = await fetch("/admin/users/filter/" + role);
            //console.log(response)
            let data = await response.json();
            //console.log(data);
            return data;
        }

        async function countFilteredUsers(role=0) {
            if (role == 0) {
                users = await getUsers();
            } else {
                users = await getUsersFilter(role);
            }
            return users;
        }


        // Кнопки сортировки

        // Функции


        async function getUsers() {
            let response = await fetch("<?php echo e(route('admin.usersall')); ?>");
            let data = await response.json();
            console.log(data);
            return data;
        }

        function clearContainer(list, count) {
            list.innerHTML = ``;
            count.innerHTML = ``;
        }


        function getUsersRow({name, role, comment_count, id}) {
            let path='/admin/users/edit/'+id;

            return `
         <div class="d-flex justify-content-between">
             <div class="d-flex"><p>${name}</p>- ${role}  -
                  <p>${comment_count} комментариев</p>
             </div>
             <a href="${path}" id='basket' class="btn btn-primary">Подробно</a>
         </div>
    `;
        }



        function countUsers(users) {
            let count = document.querySelector("#countUsers");
            let list = document.querySelector("#list");
            clearContainer(list, count);
            let text = "Найдено: ";
            count.innerHTML += text + users.length;
            console.log(users[0]);
            users.forEach(user => {
                list.innerHTML += `<li class="list-group-item">${getUsersRow(user)}</li>`;
            });

        }

        async function start() {
            users = await countFilteredUsers();
            //console.log(users)
            countUsers(users)
        }


        start();

        // document.
    </script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/l/lomtsols/lomtsols.beget.tech/public_html/resources/views/admin/users.blade.php ENDPATH**/ ?>