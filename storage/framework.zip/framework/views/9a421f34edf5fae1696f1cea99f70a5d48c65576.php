<?php $__env->startSection("title","register"); ?>
<?php $__env->startSection("content"); ?>
    <p class="display-4"> Здравствуй, <?php echo e($moderator->name); ?> </p>
    <button class="btn" id="like">&#129293;</button>


    <script>
        document.getElementById("like").addEventListener('click',function (e){
            e.target.innerHTML="&#128155;";
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.moderator', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\goldengirls\resources\views/moderator/panel.blade.php ENDPATH**/ ?>