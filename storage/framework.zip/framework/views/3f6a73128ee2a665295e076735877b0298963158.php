<?php $__env->startSection("title","Главная"); ?>
<?php $__env->startSection("content"); ?>
<div class="card mb-3 mt-5 p-5">
<?php echo $__env->make("inc.error", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <form action="<?php echo e(route('admin.post.update',$post)); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PATCH'); ?>
            <div class="input-group mb-4">
                <span class="input-group-text" id="inputGroup-sizing-default">Название статьи</span>
                <input type="text" name="title" class="form-control" value="<?php echo e($post->title); ?>" aria-label="Sizing example input"
                       aria-describedby="inputGroup-sizing-default" >
            </div>

            <div class="input-group mb-4">
                <span class="input-group-text" id="inputGroup-sizing-default">Категории</span>
                <select class="form-select" name="topic">
                    <option value="<?php echo e($topics->id); ?>"><?php echo e($topics->topic); ?></option>
                </select>
            </div>

            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-danger"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <div class="form-floating mt-4">
                <textarea name="article" class="form-control" placeholder="Leave a comment here"
                          id="floatingTextarea" style="height: 180px; resize: none;" ><?php echo e($post->article); ?></textarea>
                <label for="floatingTextarea">Карточка</label>
            </div>

            <div class="input-group mt-4">
                <span class="input-group-text" id="inputGroup-sizing-default">Актёр / Режиссер</span>
                <input type="text" name="by" class="form-control" value="<?php echo e($post->made_by); ?>" aria-label="Sizing example input"
                       aria-describedby="inputGroup-sizing-default" >
            </div>

            <div class="form-floating mt-4">
                <textarea name="description" class="form-control" placeholder="Leave a comment here"
                          id="floatingTextarea" style="height: 180px; resize: none;" ><?php echo e($post->description); ?></textarea>
                <label for="floatingTextarea">Описание</label>
            </div>


            <div class="form-floating mt-4">
                <textarea name="content" class="form-control" placeholder="Leave a comment here"
                          id="floatingTextarea" style="height: 180px; resize: none;" ><?php echo e($post->content); ?></textarea>
                <label for="floatingTextarea">Текст статьи</label>
            </div>

            <div class="form-floating mt-4">
                <textarea name="facts" class="form-control" placeholder="Leave a comment here"
                          id="floatingTextarea" style="height: 180px; resize: none;" ><?php echo e($post->facts); ?></textarea>
                <label for="floatingTextarea">Интерестные факты</label>
            </div>

            <?php if(!empty($images)): ?>
            <div class="mt-4 d-flex justify-content-around flex-wrap">
                <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="deleteImage[]" value="<?php echo e($image->image); ?>" id="flexCheckDefault">
                    <label class="form-check-label" for="flexCheckDefault">
                    <abbr title="Удалить?" class="initialism"><img src="<?php echo e(asset($image->image_full)); ?>" alt="<?php echo e($image->type); ?>" height="120" width="120"/></abbr>
                     </label>
                </div>


                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php endif; ?>


            <div class="input-group mb-3 mt-4">
                <input type="file" name="images[]" class="form-control" id="inputGroupFile02" multiple accept="image/jpeg,image/png,image/gif">
                <label class="input-group-text" for="inputGroupFile02">Загрузить 📉</label>
            </div>

            <div class="d-flex justify-content-around " id="image"></div>


            <?php if(!empty($videos)): ?>
            <div class="mt-4 d-flex justify-content-around flex-wrap">
                <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="deleteVideo[]" value="<?php echo e($video->image); ?>" id="flexCheckDefault">
                    <label class="form-check-label" for="flexCheckDefault">
                    <abbr title="Удалить?" class="initialism"><?php echo e($video->image); ?></abbr>
                     </label>
                </div>


                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php endif; ?>

            <div class="input-group mb-3 mt-4">
              <input type="file" name="video[]" class="form-control" id="inputGroupFile03" multiple accept="video/mp4">
               <label class="input-group-text" for="inputGroupFile03">Загрузить 📹</label>
           </div>





            <div class="input-group mb-3 mt-4">
                <label class="input-group-text" for="inputData">Дата</label>
                <input class="form-control" type="text" name="post-date" value="<?php echo e(date('d.m.Y')); ?>"
                       aria-label="readonly input example" readonly id="inputData">
            </div>

            <div class="input-group mb-4">
                <span class="input-group-text" id="inputGroup-sizing-default">Страна</span>
                <select class="form-select mr-sm-2" name="country">
                    <option value="<?php echo e($country->id); ?>"><?php echo e($country->flag); ?></option>
                </select>
            </div>


            <button name="post-button" class="btn btn-primary btn-lg">Отправить</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\goldengirls\resources\views/post/edit.blade.php ENDPATH**/ ?>