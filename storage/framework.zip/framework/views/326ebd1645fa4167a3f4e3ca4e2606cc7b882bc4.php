<header class="navbar navbar-dark sticky-top bg-info flex-md-nowrap p-0 shadow">
    <a class="navbar-brand col-md-3 col-lg-2 me-0 px-3" href="<?php echo e(route('user')); ?>"><?php echo e($user->name); ?></a>
    <div class="navbar-nav">
        <div class="nav-item text-nowrap">
            <a class="nav-link px-3" href="<?php echo e(route('logout')); ?>">Выйти</a>
        </div>
    </div>
</header>
<?php /**PATH /home/l/lomtsols/lomtsols.beget.tech/public_html/resources/views/inc/user/navbar.blade.php ENDPATH**/ ?>