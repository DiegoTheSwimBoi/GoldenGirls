<?php
 ?><?php /**PATH C:\OpenServer\domains\goldengirls\resources\views/post/file.blade.php ENDPATH**/ ?>