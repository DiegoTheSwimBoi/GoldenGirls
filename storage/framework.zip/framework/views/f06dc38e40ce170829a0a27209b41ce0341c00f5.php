<?php $__env->startSection("title",$post['title']); ?>


<?php $__env->startSection("content"); ?>
    <div class="d-flex align-items-stretch">
        <div class="characters"></div>
    </div>
    <div class="container-body text-light">
            <?php echo $__env->make('inc.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php if(auth()->guard()->guest()): ?>
            <div class="mt-5">
                <form method="post" action="<?php echo e(route('post.lang.update')); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('POST'); ?>
                    <div class="row">
                        <?php $__currentLoopData = $flags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $flag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-3">
                                <label for="<?php echo e($flag->flag); ?>">
                                    <input type="radio" onchange="this.form.submit()" value="<?php echo e($flag->flag); ?>" name="country" style="display: none;"
                                           id="<?php echo e($flag->flag); ?>" <?php echo e($flag->flag==$lang?'checked':''); ?>>
                                    <img src="<?php echo e($flag->flag_img); ?>" alt="<?php echo e($flag->flag); ?>">
                                </label>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </form>
            </div>
            <?php endif; ?>
        </div>
        <div class="p-md-5">
            <hr class="logo-line">
        </div>
        <div class="container text-center">
            <div class="title text-center "><h1><?php echo e($post['about-show-title']); ?></h1></div>
            <div class="flex-content mt-5">
                <?php $__currentLoopData = $post['about-show']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div>
                        <p class="text-start"><?php echo e($section); ?></p>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="text-end">
                <div class="p-5">
                    <a href="<?php echo e(route('creators')); ?>"
                       class="text-decoration-none hover pink"><?php echo e($data['more-about']['show']); ?>

                    </a>
                </div>
            </div>
        </div>
        <div class="mt-5 mb-5">
            <?php $__currentLoopData = $post['characters']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($key==1): ?>
                    <div class="d-flex justify-content-around flex-wrap"><?php endif; ?>
                        <div class="<?php echo e($section['class']); ?>">
                            <img src="<?php echo e(asset($section['img'])); ?>"
                                 alt="<?php echo e($section['name']); ?>"
                                 class="border border-5 border-white rounded-circle shadow p-3 mb-5 bg-dark rounded"/>
                            <p style="width: 20rem;"><?php echo e($section['info']); ?></p>
                            <p><?php echo e($section['name']); ?></p>
                        </div>
                        <?php if($key==2): ?></div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="text-end">
                <div class="p-5">
                    <a href="<?php echo e(route('characters')); ?>"
                       class="text-decoration-none hover pink"><?php echo e($data['more-about']['character']); ?></a>
                </div>
            </div>
        </div>
        <div class="border-rectangle"></div>
        <div class="pink-rectangle">
            <div class="text-center">
                <video width="640" height="512" controls="controls" class="mt-5" id="video">
                    <source src="<?php echo e($post['content']['path']); ?>/pilot.mp4" type='video/mp4'
                            id="source">
                    <?php echo e($post['content']['no-video']); ?>

                </video>

                <div class="p-md-5 d-flex justify-content-center align-content-center gap-3 flex-wrap">
                    <?php $__currentLoopData = $post['content']['image']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div>
                            <label><input type="radio" name="episode" id="episode" style="display:none;"
                                          value="<?php echo e($post['content']['path']); ?>/<?php echo e($image); ?>.mp4"><img
                                    src="<?php echo e($post['content']['path']); ?>/<?php echo e($image); ?>.png"
                                    height="180" width="250"
                                    alt="Golden girls moments - <?php echo e($key); ?>"
                                    class="rounded shadow p-1 mb-5"
                                ></label>
                            <p class="text-dark" style="font-size: large; font-weight: bolder;"><?php echo e($key); ?></p>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div class="text-end">
                <div class="p-5">
                    <a href="<?php echo e(route('episodes')); ?>"
                       class="text-decoration-none hover-black black"><?php echo e($data['more-about']['episode']); ?></a>
                </div>
            </div>
        </div>
    </div>
    <div class="border-rectangle"></div>
    <div class="container-body text-light">
        <div class="p-5 mt-8 mb-8">
            <h2 class="text-center"><?php echo e($post['award-title']); ?></h2>
            <div style="margin-top: 5rem; font-size: 18px;">
                <?php $__currentLoopData = $post['award']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="d-flex justify-content-center content-center">
                        <p><?php echo e($section['title']); ?></p>
                        <p><?php echo e($section['name']); ?></p>
                    </div>
                    <div class="p-md-5">
                        <hr class="award-line">
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <?php echo $__env->make("inc.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        let episodes = document.querySelectorAll("#episode");
        episodes.forEach(episode => {
            episode.addEventListener("click", function (e) {
                document.getElementById("source").src = e.target.value;
                document.getElementById("video").load();
                document.getElementById("video").scrollIntoView();
            })
        });

    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/l/lomtsols/lomtsols.beget.tech/public_html/resources/views/welcome.blade.php ENDPATH**/ ?>