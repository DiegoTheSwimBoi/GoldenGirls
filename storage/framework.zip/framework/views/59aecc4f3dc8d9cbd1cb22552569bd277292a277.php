<?php $__env->startSection("content"); ?>
<div>
    <p class="display-6">Привет, <?php echo e($admin->name); ?>- <?php echo e($admin->role->role); ?></p>
    <div class="d-flex justify-content-evenly flex-wrap mt-5">
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/l/lomtsols/lomtsols.beget.tech/public_html/resources/views/admin/panel.blade.php ENDPATH**/ ?>