<?php if(!empty($post->comments)): ?>
<div class="mt-5 mb-5">
    <h3>Комментарии</h3>
    <hr>
</div>
    <?php if(auth()->guard()->check()): ?>
        <div>
            <form action="<?php echo e(route('comment.store',$post)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('POST'); ?>
                <div class="form-floating mt-4">
                <textarea name="comment" class="form-control" placeholder="Leave a comment here"
                          id="floatingTextarea" style="height: 180px; width: 100%; resize: none;"></textarea>
                    <label for="floatingTextarea" class="text-muted">Оставьте свой комментарий</label>
                </div>
                <div class="mt-3">
                    <button name="post-button" class="btn btn-primary btn-lg">Отправить</button>
                </div>
            </form>
        </div>
    <?php endif; ?>
    <div class="mt-5 ">

        <?php $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($comment->posted): ?>

                <div>
                    <div class="d-flex justify-content-between flex-wrap">
                        <span><?php echo e($comment->user->name); ?> - <?php echo e($comment->date_comment_humans); ?></span>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['user-comment'],$comment)): ?>
                            <a href="#" class="btn-close" aria-label="Close"></a>
                            
                        <?php endif; ?>
                    </div>
                    <p class="text-muted"><?php echo e($comment->user->role->role); ?></p>
                    <p><?php echo e($comment->comment); ?></p>
                </div>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>



<?php endif; ?>
<?php /**PATH C:\OpenServer\domains\goldengirls\resources\views/inc/comments.blade.php ENDPATH**/ ?>