<?php $__env->startSection("title","Пользователь"); ?>
<?php $__env->startSection("content"); ?>
    <div class="card mb-3 mt-5 p-5">
        <p><?php echo e($user->name); ?></p>
        <div>
            <p><?php echo e($data['user']['posts-liked']); ?> <?php echo e(count($likes)); ?></p>
            <hr>
            <ul class="list-group">
                <?php $__currentLoopData = $likes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $like): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="list-group-item">
                        <div class="d-flex justify-content-between">
                            <div class="d-flex gap-3">
                                <p><?php echo e($like->title); ?></p>
                            </div>
                        </div>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/l/lomtsols/lomtsols.beget.tech/public_html/resources/views/users/likes.blade.php ENDPATH**/ ?>