<?php $__env->startSection("title",$post->title); ?>


<?php $__env->startSection("content"); ?>
    <div class="d-flex justify-content-center align-content-center">
        <div class="row w-100 mt-5">
            <div class="col-sm-2 mb-5 phone-version">
                <div class="card col-3" style="width: 18rem; background-color: rgb(39, 35, 35);">
                    <img src="/storage/<?php echo e($post->images[0]->image); ?>" alt="<?php echo e($post->title); ?>" height="300"
                         class="card-img-top">
                    <div class="card-body text-white">
                        <h3 class="card-title text-center"><?php echo e($post->title); ?></h3>
                        <hr>
                        <div><?php echo $post->article; ?></div>
                        <small><?php echo e($post->made_by); ?></small>
                    </div>
                </div>
            </div>

            <div class="gap-2 col-sm-9 text-white" style="background-color: rgb(39, 35, 35); ">
                <div class="mt-3 p-3" style="font-size: large;">
                    <div class="row">
                    <h1 class="col-6"><?php echo e($post->title); ?></h1>
                    <a href="javascript:history.back()" class="col-1 mt-3 text-decoration-none hover pink"><?php echo e($data['back']); ?></a>
                    <a href="<?php echo e(route('welcome')); ?>" class="col-2 mt-3 text-decoration-none hover pink"><?php echo e($data['main']); ?></a>
                    </div>
                        <hr>
                    <div class="w-75">
                        <?php echo e($post->description); ?>

                        <hr>
                    </div>
                    <div class="mt-3"><?php echo $post->content; ?></div>
                    <h3 class="mt-3">Интерестные факты</h3>
                    <hr>
                    <div class="p-2">
                        <ul><?php echo $post->facts; ?></ul>
                    </div>
                    <h3 class="mt-3">Галерея</h3>
                </div>
                <hr>
                <div class="p-3 row">
                    <?php $__currentLoopData = $post->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <img src="<?php echo e($image->image_full); ?>" class="col-sm-3 mt-2" style="object-fit: cover;" alt="<?php echo e($post->title); ?>" data-bs-toggle="modal" data-bs-target="#modalDestroy">
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                </div>
                <div class="mt-5"><?php echo $__env->make("inc.post-footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                <?php echo $__env->make('inc.modal_gallery', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            </div>

            <div class="col-sm-2 pc-version">
                <div class="card col-3" style="width: 18rem; background-color: rgb(39, 35, 35);">
                    <img src="/storage/<?php echo e($post->images[0]->image); ?>" alt="<?php echo e($post->title); ?>" height="300"
                         class="card-img-top">
                    <div class="card-body text-white">
                        <h3 class="card-title text-center"><?php echo e($post->title); ?></h3>
                        <hr>
                        <div><?php echo $post->article; ?></div>
                        <small><?php echo e($post->made_by); ?></small>
                    </div>
                </div>
            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        async function leavelike(route, _token) {
            let response = await fetch(route, {
                method: 'PATCH',
                headers: {
                    'Content-Type': 'application/json; charset=UTF-8',
                },
                body: JSON.stringify({_token}),
            });
            return await response.json();
        }

        document.getElementById("like").addEventListener("submit", async (e) => {
            e.preventDefault();
            let data = await leavelike("<?php echo e(route('add-like',$post->likes[0])); ?>", "<?php echo e(csrf_token()); ?>");
            generateCount(data);
            console.log(data);
        });

        function generateCount({like}) {
            document.getElementById("count").innerHTML = like;
            let likeButton = document.querySelector('.like');
            if (likeButton.classList.contains('no-like')) {
                likeButton.classList.remove('no-like');
                likeButton.classList.add('has-like');
            } else {
                likeButton.classList.remove('has-like');
                likeButton.classList.add('no-like');
            }
        }
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\goldengirls\resources\views/post.blade.php ENDPATH**/ ?>