<?php $__env->startSection("title",''); ?>


<?php $__env->startSection("content"); ?>
    <div class="container-body mt-5">
        <?php echo $__env->make('inc.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="row container mb-5">
            <div class="col-1"></div>
            <div class="col-10 mt-5 mb-5">
                <form>
                    <div class="input-group mb-4 w-75">
                        <input type="text" name="search" class="form-control w-75" value="<?php echo e(request('search')); ?>">
                        <button class="btn btn-secondary search"></button>
                    </div>
                </form>
            </div>
            <div class="col-1 mt-5 mb-5">
                <a href="<?php echo e(route('welcome')); ?>" class="text-decoration-none hover pink"><?php echo e($data['back']); ?></a>
            </div>

<div class="col-9 mt-5 mb-5">
    <div class="row gap-3">
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card border-secondary border-1 col-sm-3 " style="width: 18rem; background-color: rgb(39, 35, 35);">
                <img class="card-img-top" src="<?php echo e($post->images[0]->image_full); ?>" alt="<?php echo e($post->title); ?>">
                <div class="card-body">
                    <a href="<?php echo e(route($name,$post)); ?>" class="text-decoration-none hover pink"><?php echo e($post->title); ?></a>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
</div>
            <div class="col-3">
                <div class="card col-3 border-secondary border-3" style="width: 18rem; background-color: rgb(39, 35, 35);">
                    <div class="card-body text-center">
                        <h3 class="text-white"><?php echo e($data['new_posts']); ?></h3>
                        <?php if($news!==null): ?>
                            <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new_post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="mt-3"><a href="<?php echo e(route($new_post->topic->id==1?'character':'episode',$new_post)); ?>" class="text-decoration-none hover pink"><?php echo e($new_post->title); ?></a></div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

        </div>

        <div class="text-white"><?php echo $__env->make('inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\goldengirls\resources\views/category.blade.php ENDPATH**/ ?>