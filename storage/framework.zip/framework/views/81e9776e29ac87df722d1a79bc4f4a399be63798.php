<?php $__env->startSection("title","Главная"); ?>
<?php $__env->startSection("content"); ?>

<div class="card mb-3 mt-5 p-5">
        <?php echo $__env->make("inc.error", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <form action="<?php echo e(route('admin.post.store')); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('POST'); ?>
            <div class="input-group mb-4">
                <span class="input-group-text" id="inputGroup-sizing-default">Название статьи</span>
                <input type="text" name="title" class="form-control" value="<?php echo e(old('title')); ?>" aria-label="Sizing example input"
                       aria-describedby="inputGroup-sizing-default" >
            </div>

            <div class="input-group mb-4">
                <span class="input-group-text" id="inputGroup-sizing-default">Категории</span>
                <select class="form-select" name="topic">
                    <?php $__currentLoopData = $topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>:
                    <option value="<?php echo e($topic->id); ?>"  <?php echo e($topic->id==old('topic')?'selected':''); ?>><?php echo e($topic->topic); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="form-floating mt-4">
                <textarea name="article" class="form-control" placeholder="Leave a comment here"
                          id="floatingTextarea" style="height: 180px; resize: none;" ><?php echo e(old('article')); ?></textarea>
                <label for="floatingTextarea">Карточка</label>
            </div>

            <div class="input-group mt-4">
                <span class="input-group-text" id="inputGroup-sizing-default">Актёр / Режиссер</span>
                <input type="text" name="by" class="form-control" value="<?php echo e(old('by')); ?>" aria-label="Sizing example input"
                       aria-describedby="inputGroup-sizing-default" >
            </div>

            <div class="form-floating mt-4">
                <textarea name="description" class="form-control" placeholder="Leave a comment here"
                          id="floatingTextarea" style="height: 180px; resize: none;" ><?php echo e(old('description')); ?></textarea>
                <label for="floatingTextarea">Описание</label>
            </div>

            <div class="form-floating mt-4">
                <textarea name="content" class="form-control" placeholder="Leave a comment here"
                          id="floatingTextarea" style="height: 180px; resize: none;" ><?php echo e(old('content')); ?></textarea>
                <label for="floatingTextarea">Текст статьи</label>
            </div>

            <div class="form-floating mt-4">
                <textarea name="facts" class="form-control" placeholder="Leave a comment here"
                          id="floatingTextarea" style="height: 180px; resize: none;" ><?php echo e(old('facts')); ?></textarea>
                <label for="floatingTextarea">Интерестные факты</label>
            </div>

            <div class="input-group mb-3 mt-4">
                <!--accept="image/jpeg,image/png,image/gif"-->
                <input type="file" name="images[]" class="form-control" id="inputGroupFile02" multiple >
                <label class="input-group-text" for="inputGroupFile02">Загрузить 📉</label>
            </div>

            <div class="d-flex justify-content-around" id="image"></div>


            <div class="input-group mb-3 mt-4">
              <input type="file" name="videos[]" class="form-control" id="inputGroupFile03" multiple accept="video/mp4">
               <label class="input-group-text" for="inputGroupFile03">Загрузить 📹</label>
           </div>


           <div class="d-flex justify-content-around" id="video"></div>


            <div class="input-group mb-3 mt-4">
                <label class="input-group-text" for="inputData">Дата</label>
                <input class="form-control" type="text" name="post-date" value="<?php echo e(date('d.m.Y')); ?>"
                       aria-label="readonly input example" readonly id="inputData">
            </div>

            <div class="input-group mb-4">
                <span class="input-group-text" id="inputGroup-sizing-default">Страна</span>
                <select class="form-select mr-sm-2" name="country">
                    <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>:
                    <option value="<?php echo e($country->id); ?>"  <?php echo e($country->id==old('$country')?'selected':''); ?>><?php echo e($country->flag); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>


            <button name="post-button" class="btn btn-primary btn-lg">Отправить</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\goldengirls\resources\views/post/create.blade.php ENDPATH**/ ?>