<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('likes', function (Blueprint $table) {
            $table->id();
            $table->integer('likes');
            $table->foreignId('post_id')->constrained("posts")->cascadeOnUpdate()->cascadeOnDelete();
            $table->timestamps();
        });

        Schema::create("likes_user",function (Blueprint $table){
            $table->foreignId('likes_id')->constrained("likes")->cascadeOnUpdate()->cascadeOnDelete();
            $table->foreignId('user_id')->constrained("users")->cascadeOnUpdate()->cascadeOnDelete();
            $table->primary(['likes_id','user_id']);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('likes');
        Schema::dropIfExists('like_user');
    }
};
