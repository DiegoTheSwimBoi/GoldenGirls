<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class CountrySeeder extends Seeder
{
    protected $countryFolder="/country/json/";
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $path = __DIR__.$this->countryFolder.'country.json';

        $countries_json = file_get_contents($path);
        $countries=json_decode($countries_json,false);

        if($countries){
            foreach($countries as $country){
                DB::table('countries')->insert([[
                    'country'=>$country->name,
                    'flag'=>$country->flag,
                ]]);
            }
        }
    }
}
