<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
class PostSeeder extends Seeder
{
    protected $postFolder="/post/json/";
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $path = __DIR__.$this->postFolder.'post.json';

        

        

        $post_json = file_get_contents($path);
        $posts=json_decode($post_json,false);

        $image_json= file_get_contents(__DIR__.$this->postFolder.'image.json');
        $images=json_decode($image_json,false);

        if($posts){
            foreach($posts as $post){  
                    
                    DB::table('posts')->insert([[
                        'title' => $post->title,
                        'content'=>$post->content,
                        'country_id' => $post->country_id,
                        'topic_id'=>$post->topic_id,
                    ]]);

                    DB::table('likes')->insert([[
                        "likes"=>0,
                        "post_id"=>$post->id
                    ]]);

            }

        }

        if($images){
        foreach($images as $image){  
                DB::table("images")->insert([[
                    "image"=>$image->image,
                    "type"=>$image->type,
                    "post_id"=>$image->post_id
                ]]);
        }
    }
    }
}
