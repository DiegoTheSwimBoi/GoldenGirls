<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use App\Http\Services\JSONService;

class UserSeeder extends Seeder
{
    protected $adminFolder="/users/json/";




    /**
     * Run the database seeds. Для Админов и Модераторов, чтобы запустить миграции с данными.
     *
     * @return void
     */
    public function run()
    {
        $path = __DIR__.$this->adminFolder.'users.json';

        $users=JSONService::read_json($path);

        if($users){
            foreach($users as $key=>$user){
                DB::table('users')->insert([[
                    'name'=>$user->name,
                    'email'=>$user->email,
                    'password'=>$user->password,
                    'role_id'=>$user->role_id,
                    'country_id'=>$user->country_id,
                    'remember_token' => Str::random(10)
                ]]);
            }
        }
    }
}
