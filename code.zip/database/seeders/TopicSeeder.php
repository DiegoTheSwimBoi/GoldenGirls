<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class TopicSeeder extends Seeder
{
    protected $topicFolder="/topic/json/";
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $path = __DIR__.$this->topicFolder.'topic.json';

        $topics_json = file_get_contents($path);
        $topics=json_decode($topics_json,false);

        if($topics){
            foreach($topics as $topic){
                foreach ($topic->topic as $top) {
                    DB::table('topics')->insert([[
                        'topic' => $top,
                    ]]);
                }
            }
        }
    }
}
