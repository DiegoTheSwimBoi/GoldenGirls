<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Country extends Model
{
    use HasFactory;
    public $timestamps=false;

    public function topic(){
        return $this->hasMany(Topic::class);
    }

    public function post(){
        return $this->hasMany(Post::class);
    }

    public function user(){
        return $this->hasMany(User::class);
    }

    public  function getFlagImgAttribute(){
        return '/storage/lang/'.$this->flag.'.png';
    }

}
