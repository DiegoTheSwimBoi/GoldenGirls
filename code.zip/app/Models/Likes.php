<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;

class Likes extends Model
{
    use HasFactory;

    protected $fillable=[
        "likes",
        "post_id"
    ];


    public function user(){
        return $this->belongsToMany(User::class);
    }

    public function post(){
        return $this->belongsTo(Post::class);
    }


    /**
     * @return string
     */
    public function getLikeClassAttribute()
    {
        if($this->user()->where('user_id', Auth::id())->exists()){
            return 'has-like';
        }

        return 'no-like';
    }

}
