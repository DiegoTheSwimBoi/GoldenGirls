<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Image extends Model
{
    use HasFactory;
    public $timestamps=false;

    protected $fillable = [
        'image',
        'type',
        'post_id'
    ];

    public function post(){
        return $this->belongsTo(Image::class);
    }

    public function getImageFullAttribute(){
        return '/storage/'.$this->image;
    }

    public function getImageTypeAttribute(){
        return Image::all()->where('type','image');
    }

    public function getVideoTypeAttribute(){
        return Image::all()->where('type','video');
    }
}
