<?php


namespace App\Http\Services;


class JSONService
{
    /*
     * Читает файл json и возвращает массив, иначе false;
     * */
    public static function read_json($path){
        $file_json = file_get_contents($path);
        return json_decode($file_json,false);
    }
    
    /*
     * Проверяет на наличие директории и файла, если нет, то создаёт.
     * */

	public static function create_json($directory,$file){
        if(!is_dir($directory)){
            mkdir($directory,0777,true);
        }

        if(!is_file($directory.$file)){
            touch($directory.$file);
        }
    }
  

    /*
     * Записывает в файл json, при этом смотрит на параметр one_line
     * "В одну строку" записывает массив как [{key:item}],
     * Иначе записывает массив с ключами и значениями в другом формате.
     * */
    public static function write_json($directory,$file,$obj,$one_line=true){
        $path=$directory.$file;
        $to_json=[];
        if(!empty($obj)){
            foreach ($obj as $item => $value){
                $to_json[]=$one_line?(object)["$item"=>$value]:$value;
            }
            $json=json_encode($to_json,JSON_UNESCAPED_UNICODE);

            if (!file_exists($path)){
                JSONService::create_json($directory,$file);
            }
            return file_put_contents($path, $json);
        }

        return false;
    }
}
