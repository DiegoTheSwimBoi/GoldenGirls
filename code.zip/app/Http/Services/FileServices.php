<?php


namespace App\Http\Services;


use Illuminate\Support\Facades\Storage;

class FileServices
{
    static function inputFile($files){

        $folderDefault="/";
        $imageFolder="post/images";
        $videoFolder="post/videos";

        $IMAGE_MIME_TYPE=["image/jpeg","image/png","image/gif"];

        $VIDEO_MIME_TYPE=["video/mp4"];

        $path=[];



        if(!empty($files)){
            foreach($files as $file){
                if(in_array($file->getMimeType(),$IMAGE_MIME_TYPE)){
                    $path[]=$file->store($folderDefault.$imageFolder,'public');
                }elseif(in_array($file->getMimeType(),$VIDEO_MIME_TYPE)){
                    $path[]=$file->store($folderDefault.$videoFolder,'public');
                }
            }

            return $path;

        }

        return false;
    }


    static function deleteFile($file){
        $default="/public/";
        $path=$default.$file;
        if(Storage::exists($path)){
            Storage::delete($path);
        }
    }
}


