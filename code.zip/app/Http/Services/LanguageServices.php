<?php

namespace App\Http\Services;

class LanguageServices
{
    static protected $messages = [
        'ru' => [
            'header' => [
                'episodes' => 'Эпизоды',
                'characters' => 'Персонажи',
                'about' => 'О нас',
                'creators' => 'О создателях',
            ],
            'login' => 'Зарегистрируйтесь, чтобы оставить комментарий',
            'back' => 'Назад',
            'main' => 'На Главную',
            'logout' => 'Выйти',
            'new_posts'=>'Новые посты',
			'gallery'=>'Галерея',
			'facts'=>'Интерестные факты',
            'user' => [
                'login' => '👑 Ввойти в личный кабинет',
                'fav-posts' => 'Мои ❤ посты',
                'comments' => 'Комментарии',
                'settings' => '⚙ Настройки',
                'comments-posted' => 'Комментарие, которые вы написали:',
                'posts-liked' => 'Статьи, которые вам понравились:',
                'setting' => [
                    'name' => 'Логин',
                    'newPassword' => 'Введите новый пароль',
                    'oldPassword' => 'Введите старый пароль',
                    'update'=>'Изменить',
                ]
            ],
            'more-about' => [
                'show' => 'Узнать больше «О шоу»...',
                'character' => 'Узнать больше «О героях»...',
                'episode' => 'Посмотреть «Список серий»...',
                'about' => 'Узнать больше «про нас»...'
            ],
            'footer' => [
                '© Все права принадлежат каналу NBC и компании «Touchstone Television»',
                '© Озвучка ДыроШтепсель'
            ],
        ],
        'us' => [
            'header' => [
                'episodes' => 'Episodes',
                'characters' => 'Characters',
                'about' => 'About us',
                'creators' => 'About creators',
            ],
            'login' => 'Register to leave a comment',
            'back' => 'Back',
            'main' => 'Main Page',
            'logout' => 'Logout',
            'new_posts'=>'New posts',
			'gallery'=>'Gallery',
			'facts'=>'Interesting facts',
            'user' => [
                'login' => '👑 My account',
                'fav-posts' => 'My ❤ posts',
                'comments' => 'Comments',
                'settings' => '⚙ Settings',
                'comments-posted' => 'The comments you wrote:',
                'posts-liked' => 'Articles you liked:',
                'setting' => [
                    'name' => 'Login',
                    'newPassword' => 'Enter a new password',
                    'oldPassword' => 'Enter an old password',
                    'update'=>'Update',
                ]
            ],
            'more-about' => [
                'show' => 'Learn more «About the show»...',
                'character' => 'Learn more «About Heroes»...',
                'episode' => 'View the «List of episodes»...',
                'about' => 'Learn more «About us»...'
            ],
            'footer' => [
                '© All rights belong to NBC and «Touchstone Television»',
                '© Russian Voice dub by DyroShtepsel'
            ],
        ],
        'cn' => [
            'header' => [
                'episodes' => '剧集',
                'characters' => '字符',
                'about' => '关于我们',
                'creators' => '关于创作者',
            ],
            'login' => '注册后发表评论',
            'back' => '返回',
            'main' => '转到主',
            'logout' => '注销',
            'new_posts'=>'新帖子',
			'gallery'=>'画廊',
			'facts'=>'有趣的事实',
            'user' => [
                'login' => '👑 登录您的帐户',
                'fav-posts' => '我的 ❤ 帖子',
                'comments' => '评论',
                'settings' => '⚙ 设置',
                'comments-posted' => '您发表的评论：',
                'posts-liked' => '你喜欢的帖子：',
                'setting' => [
                    'name' => '登录',
                    'newPassword' => '输入新密码',
                    'oldPassword' => '输入旧密码',
                    'update'=>'改变',
                ]
            ],
            'more-about' => [
                'show' => '了解更多关于演出...',
                'character' => '了解更多关于角色...',
                'episode' => '查看剧集列表...',
                'about' => '了解更多关于我们...'
            ],
            'footer' => [
                '© NBC 和 Touchstone 电视台保留所有权利',
                '© 孔塞之声 ДыроШтепсель'
            ],
        ],
        'es' => [
            'header' => [
                'episodes' => 'Episodios',
                'characters' => 'Personajes',
                'about' => 'Acerca de nosotros',
                'creators' => 'Acerca de los creadores',
            ],
            'login' => 'Registrarse para dejar un comentario',
            'back' => 'Atrás',
            'main' => 'Ir a principal',
            'logout' => 'Cerrar sesión',
            'new_posts'=>'Nuevas publicaciones',
			'gallery'=>'Galería',
			'facts'=>'Datos interesantes',
            'user' => [
                'login' => '👑 Inicie sesión en su cuenta',
                'fav-posts' => 'Mis ❤ publicaciones',
                'comments' => 'Comentarios',
                'settings' => '⚙ Configuración',
                'comments-posted' => 'El comentario que publicaste:',
                'posts-liked' => 'Publicaciones que te gustaron:',
                'setting' => [
                    'name' => 'Iniciar sesión',
                    'newPassword' => 'Ingrese una nueva contraseña',
                    'oldPassword' => 'Ingrese la contraseña anterior',
                    'update'=>'Actualizar',
                ]
            ],
            'more-about' => [
                'show' => 'Más información Sobre el programa...',
                'character' => 'Aprende más Acerca de los personajes...',
                'episode' => 'Ver Lista de episodios...',
                'about' => 'Aprenda más acerca de nosotros...'
            ],
            'footer' => [
                '© Todos los derechos reservados a NBC y Touchstone Television',
                '© Voz del Tapón del Agujero'
            ],
        ],
    ];

    protected static $post = [
        'ru' => [
            'main' => [
                'title' => 'Golden girls - Главная',
                'about-show-title' => '«О шоу»',
                'about-show' => ['«Золотые девочки» (англ. «The Golden Girls») — американский телесериал канала NBC, созданный Сьюзан Харрис и произведенный компанией «Touchstone Television». В США выходил в эфир с 14 сентября 1985 до 9 мая 1992. Главные роли исполнили Беатрис Артур, Бетти Уайт, Ру Макклэнахан и Эстель Гетти.', 'Ситком оригинально был задуман Брандоном Тартикоффом, а создан Сюзан Харрис. Тартикофф, однажды придя в гости к своей пожилой тёте, заметил, как она ведёт себя со своей соседкой и лучшей подругой. Несмотря на то, что они постоянно спорили и препирались друг с другом, они остались лучшими друзьями и любили друг друга.', 'Телесериал был 65 раз номинирован и получил 11 премий «Эмми» (в том числе дважды в категории «Лучший комедийный телесериал»), четыре премии «Золотой глобус» и две премии «Viewers For Quality Television». Все главные актрисы также получили «Эмми». «Золотые девочки», «Дела семейные» и «Уилл и Грейс» — единственные сериалы, все исполнители главных ролей в которых выиграли «Эмми»'],
                'characters' => [
                    [
                        'img' => '/storage/characters/view/welcome/icons/dorothy2.png',
                        'info' => 'Не стойте на пути Дороти. Её пессимизм и сарказм - снесёт всех с её пути.',
                        'name' => '«Дороти Зборнак»',
                        'class' => 'd-flex justify-content-center content-center',
                    ],
                    [
                        'img' => '/storage/characters/view/welcome/icons/rose.png',
                        'info' => 'Роуз - это лучик света в царстве тьмы. Несмотря на свою расстеряность, она остается верной себе и своим друзьям.',
                        'name' => '«Роуз Найлунд»',
                        'class' => 'text-center content-center',
                    ],
                    [
                        'img' => '/storage/characters/view/welcome/icons/sofia.png',
                        'info' => 'София - лучший итальянский шеф-повар, она всегда готова поделиться секретом готовки.',
                        'name' => '«София Петрилло»',
                        'class' => 'text-center content-center',
                    ],
                    [
                        'img' => '/storage/characters/view/welcome/icons/blanche.png',
                        'info' => 'Бланш - не просто красотка в этом доме, она - шальная императрица.',
                        'name' => '«Бланш Деверо»',
                        'class' => 'd-flex justify-content-center content-center',
                    ]
                ],
                'content' => [
                    'path' => '/storage/characters/view/welcome/video/',
                    'no-video' => 'Тег video не поддерживается вашим браузером.',
                    'image' => ['Пилотная серия' => 'pilot', 'Смешанные благословения' => 'family', 'Маленький романс' => 'shrimp', 'Как мы все встетились' => 'story'],
                ],
                'award-title' => 'Награды',
                'award' => [
                    ['title' => 'Лучшая женская роль – телесериал, мюзикл или комедия', 'name' => '«Золотой глобус»'],
                    ['title' => 'Премия за телевидение: Эпизодическая комедия', 'name' => '«Гильдия писателей Америки»'],
                    ['title' => 'Самая смешная исполнительница второго плана в телесериале.', 'name' => '«Американская комедийная премия»']
                ],
            ],
            'about' => [
                'title' => 'О нас',
                'content' => ['Данный сайт создавался для поддержки забытого западного сериала, который имеет двух голосую русскую озвучку, официального дубляжа так и всё ещё нет.', 'Надеемся, что данный сайт, поможет познакомить вас с ним. Чтобы поднять себе настроение', 'Сайт создавался с использованием фреймворка Laravel, все материалы были взяты из открытого источника.'],
            ],
            'creators' => [
                'title' => 'О создателях',
                'message' => 'Спасибо За То, Что Ты Друг',
                'content' => ['«Golden Girls», также известные как « Золотые девочки» (или «Золотые годы в Латинской Америке») —американский телевизионный ситком , созданный Сьюзен Харрис и первоначально транслировавшийся Национальной радиовещательной компанией (NBC) с 1985 по 1992 год . Шоу с Беатрис Артур , Бетти Уайт , Рю МакКланахан и Эстель Гетти в главных ролях, рассказывает историю четырех разведенных или овдовевших женщин, проживающих в шале в Майами . , Флорида . Произведенный Witt/Thomas/Harris Productions совместно с Touchstone Television , сериал был исполнительным продюсером Харрисом и его коллегами Тони Томасом и Полом Юнгером Виттом.', 'В начале сериала три женщины средних лет проживают вместе в модном доме в Майами, Флорида. Домовладелица, вдова Бланш Деверо познакомилась со вдовой Розой Найлунд и разведённой Дороти Зборнак, которые ответили на объявление в местной бакалее об аренде комнаты. Позже к ним присоединяется мать Дороти, София Петрилло, когда её дом для престарелых «Тенистые сосны» сгорел дотла. В пилотном эпизоде также появляется гомосексуальный домоправитель Коко (Чарльз Левин), но впоследствии от этого персонажа отказались. София первоначально должна была появиться в качестве эпизодического персонажа, но завоевала большую популярность и присоединилась к основному ансамблю.', 'Первоначально Макклэнахэн предложили роль Розы, а Уайт — роль Бланш, но обе актрисы посчитали роли слишком похожими на те, что они раньше играли. Уайт сыграла похотливую Сью Энн Нивенс в «Шоу Мэри Тайлер Мур», а Макклэнахан снималась в главной роли милой рассеянной Вивиан Хармон вместе с Артур в телесериале «Мод».', 'Бетти Уайт на момент своей смерти в декабре 2021 года была последней в живых из главных актрис. Другие исполнительницы скончались в 2008 (Гетти), 2009 (Артур) и в 2010 (МакКлэнахан) годах.', 'В 2006 году в России на Первом канале вышла русская версия «Золотых девочек» под названием «Большие девочки». Главную роль в сериале исполнила Ольга Остроумова.']
            ],
        ],
        'us' => [
            'main' => [
                'title' => 'Golden girls - Main',
                'about-show-title' => '«The Show»',
                'about-show' => ['«The Golden Girls» — American NBC television series created by Susan Harris and produced by Touchstone Television. Aired in the US from September 14, 1985 to May 9, 1992. Starring Beatrice Arthur, Betty White, Rue McClanahan and Estelle Getty.', 'The sitcom was originally conceived by Brandon Tartikoff and created by Susan Harris. Tartikoff, once visiting his elderly aunt, noticed how she behaves with her neighbor and best friend. Despite the fact that they constantly argued and bickered with each other, they remained best friends and loved each other.', 'The television series was nominated 65 times and won 11 Emmy awards (including twice in the category "Outstanding Comedy Television Series" ), four Golden Globe Awards and two Viewers For Quality Television Awards. All the main actresses also received an Emmy. "The Golden Girls", "Family Matters" and "Will & Grace" are the only series in which all the leading actors won an Emmy'],
                'characters' => [
                    [
                        'img' => '/storage/characters/view/welcome/icons/dorothy2.png',
                        'info' => "Don't get in Dorothy's way. Her pessimism and sarcasm will blow everyone out of her way",
                        'name' => '«Dorothy Zbornak»',
                        'class' => 'd-flex justify-content-center content-center',
                    ],
                    [
                        'img' => '/storage/characters/view/welcome/icons/rose.png',
                        'info' => 'Rose is a beacon of light in the realm of darkness. Despite her confusion, she remains true to herself and her friends.',
                        'name' => '«Rose Nylund»',
                        'class' => 'text-center content-center',
                    ],
                    [
                        'img' => '/storage/characters/view/welcome/icons/sofia.png',
                        'info' => 'Sofia is the best Italian chef, she is always ready to share the secret of cooking.',
                        'name' => '«Sofia Petrillo»',
                        'class' => 'text-center content-center',
                    ],
                    [
                        'img' => '/storage/characters/view/welcome/icons/blanche.png',
                        'info' => 'Blanche is not just a beauty in this house, she is a queen',
                        'name' => '«Blanche Devereux»',
                        'class' => 'd-flex justify-content-center content-center',
                    ]
                ],
                'content' => [
                    'path' => '/storage/characters/view/welcome/video/',
                    'no-video' => 'The video tag is not supported by your browser.',
                    'image' => ['Pilot' => 'pilot', 'Mixed blessings' => 'family', 'A little romance' => 'shrimp', 'How we all met' => 'story'],
                ],
                'award-title' => 'Awards',
                'award' => [
                    ['title' => 'Best Actress - Television Series Musical or Comedy', 'name' => '«Golden Globe»'],
                    ['title' => 'TV Award: Episodic Comedy', 'name' => '«Writers Guild of America»'],
                    ['title' => 'Funniest Supporting Actress in a TV Series.', 'name' => '«American Comedy Awards»']
                ],
            ],
            'about' => [
                'title' => 'About us',
                'content' => ['This site was created for fans of the show who love this show.', 'We hope this site will help you get to know it. To cheer yourself up', 'The site was created using the Laravel framework, all materials were taken from open source.'],
            ],
            'creators' => [
                'title' => 'About creators',
                'message' => 'Thank You For Being A Friend',
                'content' => ["Golden Girls (or Golden Years in Latin America), is an American television sitcom created by Susan Harris and originally broadcast by the National Broadcasting Company (NBC) from 1985 to 1992. The show, starring Beatrice Arthur, Betty White, Rue McClanahan and Estelle Getty, tells the story of four divorced or widowed women living in a chalet in Miami. , Florida . Produced by Witt/Thomas/Harris Productions in association with Touchstone Television, the series was executive produced by Harris and co-stars Tony Thomas and Paul Junger Witt.", "At the start of the series, three middle-aged women live together in a fashion house in Miami, Florida. The landlady, widow Blanche Devereaux, met widow Rosa Nylund and divorcee Dorothy Zbornak, who answered an ad in a local grocery for a room. They are later joined by Dorothy's mother, Sophia Petrillo, when her Shady Pines nursing home burned to the ground. The pilot episode also features the homosexual housekeeper Coco (Charles Levin), but the character was subsequently dropped. Sophia was originally supposed to appear as a cameo character, but gained a lot of popularity and joined the main cast.", "Initially, McClanahan was offered the role of Rose and White was offered the role of Blanche, but both actresses felt the roles were too similar to what they had previously played. White played the lascivious Sue Ann Nivens on The Mary Tyler Moore Show, and McClanahan starred as the lovable, absent-minded Vivian Harmon alongside Arthur on the television series Maud.", "Betty White was the last survivor at the time of her death in December 2021 of the main actresses. Other performers passed away in 2008 (Getty), 2009 (Arthur) and 2010 (McClanahan)."],
            ],
        ],
        'cn' => [
            'main' => [
                'title' => 'Golden Girls - Home',
                'about-show-title' => '«关于演出»',
                'about-show' => ['The Golden Girls 是由 Susan Harris 创作并由 Touchstone 电视台制作的美国 NBC 电视连续剧。 1985 年 9 月 14 日至 1992 年 5 月 9 日在美国播出。由 Beatrice Arthur、Betty White、Rue McClanahan 和 Estelle Getty 主演。塔蒂科夫曾经拜访他年迈的姑姑 注意到她与邻居和最好的朋友相处的方式。尽管他们经常争吵和争吵', '但他们仍然是最好的朋友，彼此相爱。”、“这部电视剧获得了 65 次提名，并获得了 11 项艾美奖（包括两次“杰出喜剧电视剧”类别） 、四个金球奖和两个观众为质量电视奖。所有的主要女演员也都获得了艾美奖。 《黄金女郎》、《家庭事务》和《威尔与格蕾丝》是唯一一部所有主演都获得艾美奖的剧集'],
                'characters' => [
                    [
                        'img' => '/storage/characters/view/welcome/icons/dorothy2.png',
                        'info' => '不要妨碍多萝西。她的悲观和讽刺将把每个人都吓坏了。',
                        'name' => '«多萝西·兹博纳克»',
                        'class' => 'd-flex justify-content-center content-center',
                    ],
                    [
                        'img' => '/storage/characters/view/welcome/icons/rose.png',
                        'info' => '尽管她很困惑，但她仍然忠于自己和她的朋友。',
                        'name' => '«玫瑰尼伦德»',
                        'class' => 'text-center content-center',
                    ],
                    [
                        'img' => '/storage/characters/view/welcome/icons/sofia.png',
                        'info' => '是最好的意大利厨师，她随时准备分享烹饪的秘诀。',
                        'name' => '«索菲亚·佩特里洛»',
                        'class' => 'text-center content-center',
                    ],
                    [
                        'img' => '/storage/characters/view/welcome/icons/blanche.png',
                        'info' => '布兰奇不仅是这所房子里的美女，她还是一位皇后。',
                        'name' => '«布兰奇·德弗罗»',
                        'class' => 'd-flex justify-content-center content-center',
                    ]
                ],
                'content' => [
                    'path' => '/storage/characters/view/welcome/video/',
                    'no-video' => '您的浏览器不支持视频标签。',
                    'image' => ['飞行员' => 'pilot', '喜忧参半' => 'family', '一点浪漫' => 'shrimp', '我们是怎么认识的' => 'story'],
                ],
                'award-title' => '奖项',
                'award' => [
                    ['title' => '最佳女主角 - 音乐剧或喜剧电视剧', 'name' => '金球奖'],
                    ['title' => '电视奖：情景喜剧', 'name' => '美国作家协会'],
                    ['title' => '电视剧中最有趣的女配角', 'name' => '美国喜剧奖']
                ],
            ],
            'about' => [
                'title' => '关于我们',
                'content' => ['这个网站是为喜欢这个系列的系列粉丝创建的。', '我们希望这个网站能帮助您熟悉它。 让自己振作起来', '该网站是使用 Laravel 框架创建的，所有材料均来自开源。'],
            ],
            'creators' => [
                'title' => '关于创作者',
                'message' => '跟你做朋友太好了',
                'content' => ['«Golden Girls» 美国电视情景喜剧，由苏珊哈里斯创作，最初由国家广播公司 (NBC) 从 1985 年到 1992 年播出。该节目讲述了四名离婚或丧偶妇女住在迈阿密小木屋的故事。 ，佛罗里达州。该系列由 Witt Thomas Harris Productions 与 Touchstone 电视联合制作，由 Harris 和联合主演 Tony Thomas 和 Paul Junger Witt 执行制作。在系列开始时，三位中年女性一起居住在佛罗里达州迈阿密的时装屋屋。女房东，寡妇布兰奇·德弗罗（Blanche Devereaux）遇到了寡妇罗莎·尼伦德（Rosa Nylund）和离婚的​​多萝西·兹博纳克（Dorothy Zbornak），后者在当地一家杂货店回答了一个房间的广告。后来多萝西的母亲索菲亚·佩特里洛也加入了他们的行列，当时她的黑松疗养院被烧毁了。试播集还以同性恋管家可可（查尔斯·莱文饰）为主角，但该角色随后被删除。索菲亚原本应该是客串角色，但获得了很大的人气并加入了主要演员阵容。最初，麦克拉纳汉得到了罗斯的角色，怀特得到了布兰奇的角色，但两位女演员都觉得角色太相似了他们以前玩过的。 White 在 The Mary Tyler Moore Show 中扮演好色的 Sue Ann Nivens，而 McClanahan 在电视连续剧 Maude 中与 Arthur 一起饰演可爱、心不在焉的 Vivian Harmon。其他表演者于 2008 年（盖蒂）、2009 年（亚瑟）和 2010 年（麦克拉纳汉）去世。'],
            ],
        ],
        'es' => [
            'main' => [
                'title' => 'Golden girls - Inicio',
                'about-show-title' => '«Acerca del programa»',
                'about-show' => ['The Golden Girls es una serie de televisión estadounidense de la NBC creada por Susan Harris y producida por Touchstone Television. Se emitió en EE. UU. del 14 de septiembre de 1985 al 9 de mayo de 1992. Protagonizada por Beatrice Arthur, Betty White, Rue McClanahan y Estelle Getty.', 'La comedia de situación fue concebida originalmente por Brandon Tartikoff y creada por Susan Harris. Tartikoff, una vez que visitó a su tía anciana, notó cómo se comporta con su vecina y mejor amiga. A pesar de que discutían y discutían constantemente, seguían siendo los mejores amigos y se querían.', 'La serie de televisión fue nominada 65 veces y ganó 11 premios Emmy (incluyendo dos veces en la categoría "Serie de televisión de comedia destacada"). , cuatro premios Globo de Oro y dos premios Viewers For Quality Television. Todas las actrices principales también recibieron un Emmy. "Las chicas de oro", "Asuntos de familia" y "Will & Grace" son las únicas series en las que todos los actores principales ganaron un Emmy'],
                'characters' => [
                    [
                        'img' => '/storage/characters/view/welcome/icons/dorothy2.png',
                        'info' => 'No se interponga en el camino de Dorothy. Su pesimismo y sarcasmo dejarán a todos fuera de su camino.',
                        'name' => '«Dorothy Zbornak»',
                        'class' => 'd-flex justify-content-center content-center',
                    ],
                    [
                        'img' => '/storage/characters/view/welcome/icons/rose.png',
                        'info' => 'Rose es un faro de luz en el reino de la oscuridad. A pesar de su confusión, se mantiene fiel a sí misma y a sus amigos.',
                        'name' => '«Rose Nylund»',
                        'class' => 'text-center content-center',
                    ],
                    [
                        'img' => '/storage/characters/view/welcome/icons/sofia.png',
                        'info' => 'Sofia es la mejor chef italiana, siempre está dispuesta a compartir el secreto de la cocina.',
                        'name' => '«Sofía Petrillo»',
                        'class' => 'text-center content-center',
                    ],
                    [
                        'img' => '/storage/characters/view/welcome/icons/blanche.png',
                        'info' => 'Blanche no es solo una belleza en esta casa, es una emperatriz.',
                        'name' => '«Blanche Devereux»',
                        'class' => 'd-flex justify-content-center content-center',
                    ]
                ],
                'content' => [
                    'path' => '/storage/characters/view/welcome/video/',
                    'no-video' => 'La etiqueta de video no es compatible con su navegador.',
                    'image' => ['Piloto' => 'pilot', 'Bendiciones mixtas' => 'family', 'Un poco de romance' => 'shrimp', 'Cómo nos conocimos' => 'story'],
                ],
                'award-title' => 'Premios',
                'award' => [
                    ['title' => 'Mejor Actriz - Serie de Televisión Musical o Comedia', 'name' => '«Globo de Oro»'],
                    ['title' => 'Premio de TV: Comedia episódica', 'name' => '«Sindicato de Escritores de América»'],
                    ['title' => 'La actriz de reparto más divertida de una serie de televisión.', 'name' => '«American Comedy Awards»']
                ],
            ],
            'about' => [
                'title' => 'Sobre Nosotros',
                'content' => ['Este sitio fue creado para los fanáticos de la serie que aman esta serie.', 'Esperamos que este sitio lo ayude a familiarizarse con él. Para animarte', 'El sitio fue creado usando el framework Laravel, todos los materiales fueron tomados de código abierto.'],
            ],
            'creators' => [
                'title' => 'Sobre los creadores',
                'message' => 'Gracias por ser amiga',
                'content' => ['Golden Girls (Golden Years), es una comedia de situación de la televisión estadounidense creada por Susan Harris y transmitida originalmente por la National Broadcasting Company (NBC) de 1985 a 1992. El espectáculo, protagonizado por Beatrice Arthur, Betty White, Rue McClanahan y Estelle Getty, cuenta la historia de cuatro mujeres divorciadas o viudas que viven en un chalet en Miami. , florida Producida por Witt/Thomas/Harris Productions en asociación con Touchstone Television, la serie fue producida por Harris y sus coprotagonistas Tony Thomas y Paul Junger Witt.', 'Al comienzo de la serie, tres mujeres de mediana edad viven juntas en una casa de moda en Miami, Florida. La casera, la viuda Blanche Devereaux, conoció a la viuda Rosa Nylund y a la divorciada Dorothy Zbornak, quienes respondieron a un anuncio en una tienda de comestibles local en busca de una habitación. Más tarde se les une la madre de Dorothy, Sophia Petrillo, cuando su hogar de ancianos Shady Pines se quemó hasta los cimientos. El episodio piloto también presenta al ama de llaves homosexual Coco (Charles Levin), pero el personaje fue eliminado posteriormente. Originalmente, se suponía que Sophia aparecería como un cameo, pero ganó mucha popularidad y se unió al elenco principal', 'Inicialmente, a McClanahan se le ofreció el papel de Rose y a White se le ofreció el papel de Blanche, pero ambas actrices sintieron los papeles. eran demasiado similares a lo que habían jugado anteriormente. White interpretó a la lasciva Sue Ann Nivens en The Mary Tyler Moore Show, y McClanahan interpretó a la adorable y distraída Vivian Harmon junto a Arthur en la serie de televisión Maud.', 'Betty White fue la última sobreviviente en el momento de su muerte en Diciembre 2021 de las principales actrices. Otros artistas fallecieron en 2008 (Getty), 2009 (Arthur) y 2010 (McClanahan).']
            ],
        ],
    ];


    static protected $auth = [
        'ru'=>[
            'auth'=>[
                'email'=>'Введите email',
                'password'=>'Введите пароль',
                'remember'=>'Запомнить меня',
                'regin'=>'Войти',
                'no-account'=>'Нет аккаунта?'
            ],
            'regin'=>[
              'login'=>'Введите ваше имя',
              'email'=>'Введите email',
              'password'=>'Введите пароль',
              'password_repeat'=>'Повторите пароль',
              'captcha'=>'Введите токен с картинки',
              'regin'=>'Регистрация',
              'small'=>[
                'required'=>'обязательное поле*',
                'password'=>'больше 8 символов',
                'country'=>'страна',
              ],
            ],
        ],
        'us'=>[
            'auth'=>[
                'email'=>'Enter email',
                'password'=>'Enter password',
                'remember'=>'Remember me',
                'regin'=>'Log in',
                'no-account'=>'No account?'
            ],
            'regin'=>[
                'login'=>'Enter login',
                'email'=>'Enter email',
                'password'=>'Enter password',
                'password_repeat'=>'Repeat password',
                'captcha'=>'Enter Captcha',
                'regin'=>'Regin me',
                'small'=>[
                    'required'=>'required*',
                    'password'=>'more than 8 characters',
                    'country'=>'country'
                ],
            ],
        ],
        'cn'=>[
            'auth'=>[
                'email'=>'输入电子邮件',
                'password'=>'输入密码',
                'remember'=>'记住我',
                'regin'=>'好的',
                'no-account'=>'没有账户？'
            ],
            'regin'=>[
                'login'=>'输入登录名',
                'email'=>'输入电子邮件',
                'password'=>'输入密码',
                'password_repeat'=>'重复密码',
                'captcha'=>'输入验证码',
                'regin'=>'注册我',
                'small'=>[
                    'required'=>'必需*',
                    'password'=>'超过8个字符',
                    'country'=>'国家'
                ],
            ],
        ],
        'es'=>[
            'auth'=>[
                'email'=>'Ingresar correo electrónico',
                'password'=>'Introducir contraseña',
                'remember'=>'Recordarme',
                'regin'=>'Ok',
                'no-account'=>'¿sin cuenta?'
            ],
            'regin'=>[
                'login'=>'Ingresar inicio de sesión',
                'email'=>'Ingresar correo electrónico',
                'password'=>'Introducir contraseña',
                'password_repeat'=>'Repetir contraseña',
                'captcha'=>'Ingresar captcha',
                'regin'=>'Registrarme',
                'small'=>[
                    'required'=>'requerido*',
                    'password'=>'más de 8 caracteres',
                    'country'=>'país',
                ],
            ],
        ],
    ];


    public static function langExport($lang = 'ru')
    {
        if ($lang) {
            return self::$messages[$lang];
        }
        return self::$messages['ru'];
    }

    public static function postExport($lang = 'ru')
    {

        if ($lang) {
            return self::$post[$lang];
        }
        return self::$post['ru'];
    }

    public static function authExport($lang = 'ru')
    {
        if ($lang) {
            return self::$auth[$lang];
        }
        return self::$auth['ru'];
    }
}
