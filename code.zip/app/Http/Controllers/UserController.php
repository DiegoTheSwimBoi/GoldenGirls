<?php

namespace App\Http\Controllers;

use App\Http\Services\LanguageServices;
use Illuminate\Http\Request;
use App\Http\Requests\Auth\RegisterRequest;
use App\Models\User;
use App\Models\Comment;
use App\Models\Post;
use App\Models\Likes;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Gate;

class UserController extends Controller
{
    public function index(){
        if(Auth::user()){
            $like=Auth::user()->likes()->where('user_id', Auth::id())->count();
            return view("users.index",["user"=>Auth::user(),"like"=>$like,"data"=>LanguageServices::langExport(Auth::user()->country->flag)]);
        }

        return redirect()->route('auth.index');

    }

    public function comment(){
        if(Auth::user()){
            return view("users.comments",["user"=>Auth::user(),"comments"=>Auth::user()->comments,'data'=>LanguageServices::langExport(Auth::user()->country->flag)]);
        }

        return redirect()->route('auth.index');

    }


    public function likes(){
        if(Auth::user()){
            $posts=[];
            $user_likes=Auth::user()->likes->all();
            foreach($user_likes as $user){
                $posts[]=Post::all()->find($user->post_id);
            }

            return view("users.likes",["user"=>Auth::user(),"likes"=>$posts,'data'=>LanguageServices::langExport(Auth::user()->country->flag)]);
        }

        return redirect()->route('auth.index');
    }

    public function edit(){
        if(Auth::user()){
            return view("users.settings",["user"=>Auth::user(),'data'=>LanguageServices::langExport(Auth::user()->country->flag)]);
        }
        return redirect()->route('auth.index',['data'=>LanguageServices::langExport(Auth::user()->country->flag)]);
    }

    public function update(Request $request){
        Auth::user()->name=$request->name;
        Auth::user()->email=$request->email;
        Auth::user()->password=Hash::make($request->password);
        Auth::user()->save();
        return back();
    }







    public function delete(Comment $comment){
        if(Auth::user()){
           $comment->delete();
           return redirect()->route("user.comments");
        }
        return redirect()->route('auth.index');
    }


}
