<?php

namespace App\Http\Controllers\Moderator;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Requests\Auth\AuthRequest;
use Illuminate\Support\Facades\Auth;
use App\Models\User;
use App\Models\Role;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Storage;

class ModeratorController extends Controller
{
    public function login()
    {
        return view("moderator.login");
    }

    public function loginCheck(AuthRequest $request, User $user){
        if (Auth::attempt($request->only(['email', 'password'])) && Gate::allows('moderator')) {
            $user=User::where('email',$request->email)->first();
            if(!$user->banned){
                $request->session()->regenerate();
                return redirect()->route('moderator.dashboard', ['user' => $user]);
            }
            return back()->withErrors([
                'banned'=>'К сожалению - ваш аккаунт был заблокирован...'
            ]);
        }

        return back()->withErrors([
            'email' => 'Ошибка в аунтефикации'
        ]);
    }

    public function dashboard(){

        return view("moderator.panel",["moderator"=>Auth::user()]);
    }

    public function users()
    {
        $u=User::all()->where("role_id",3);
        return view("moderator.users", ["users" =>User::all()->where("role_id",3), "roles"=>Role::all()]);
    }

    public function banned(User $user){
        $user->banned=!$user->banned;
        $user->save();
        return back();
    }



    public function logout(){
        Auth::logout();
        request()->session()->invalidate();
        request()->session()->regenerateToken();
        return redirect()->route('moderator.login');
    }
}
