<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Resources\UserResource;
use Illuminate\Http\Request;
use App\Http\Requests\Auth\AuthRequest;
use Illuminate\Support\Facades\Auth;
use App\Models\User;
use App\Models\Role;
use App\Models\Post;
use App\Models\Image;
use App\Models\Likes;
use Illuminate\Support\Facades\Gate;
use App\Http\Services\JSONService;
use Illuminate\Support\Facades\Artisan;

class AdminController extends Controller
{
    protected $seederPath='C:/OpenServer/domains/goldengirls/database/seeders';
    protected $adminFolder="/users/json/";
    protected $postFolder="/post/json/";

    public function login()
    {
        return view("admin.login");
    }

	public function loginCheck(AuthRequest $request, User $user)
    {
        if (Auth::attempt($request->only(['email', 'password'])) && Gate::allows('admin')) {
            $request->session()->regenerate();
            Artisan::call('storage:link');
            return redirect()->route('admin.dashboard', ['user' => $user]);
        }

        return back()->withErrors([
            'email' => 'Ошибка в аунтефикации'
        ]);
    }

    public function logout()
    {
        Auth::logout();
        request()->session()->invalidate();
        request()->session()->regenerateToken();
        return redirect()->route('admin.login');
    }

    public function dashboard()
    {
        $admin = Auth::user();
        $users = User::all();
        
        return view("admin.panel", ['admin' => $admin]);
    }

    /*
     * Если админу необходимо сохранить данные в файлы json, и при перезапуске сидеров готовые данные будут заново создаваться
     * */

    public function save_admin(){


        $admins=[];
        $moderator=User::all()->where('role_id',2);

        $admins[]=['name'=>Auth::user()->name,'email'=>Auth::user()->email,'password'=>Auth::user()->password,'role_id'=>Auth::user()->role_id,'country_id'=>Auth::user()->country_id];

        foreach ($moderator as $value){
            $admins[]=['name'=>$value->name,'email'=>$value->email,'password'=>$value->password,'role_id'=>$value->role_id,'country_id'=>$value->country_id];
        }



        if(JSONService::write_json($this->seederPath.$this->adminFolder,'users.json',$admins,false)){
            return redirect()->route('admin.users');
        }

        return back();
    }

    public function save_post(){
        $to_array_Post=[];
        $to_array_Image=[];
        $posts=Post::all();
        $images=Image::all();

        foreach ($posts as $post){
            $to_array_Post[]=['id'=>$post->id, 'title'=>$post->title, 'content'=>$post->content, 'country_id'=>$post->country_id, "topic_id"=>$post->topic_id];
        }

        foreach ($images as $image){
            $to_array_Image[]=['image'=>$image->image, 'type'=>$image->type, 'post_id'=>$image->post_id];
        }

        if(JSONService::write_json($this->seederPath.$this->postFolder,'post.json',$to_array_Post,false) and JSONService::write_json($this->seederPath.$this->postFolder,'image.json',$to_array_Image,false)){
            return back();
        }

        return back();
    
    }

    public function users()
    {
        return view("admin.users", ["users" =>User::all(), "roles"=>Role::all()]);
    }

    public function usersall(){
        if (Gate::allows('admin')) {
            return UserResource::collection(User::all());
        }
        return abort(403,'God damit. You ruined your life');
    }

    public  function usersfilter(Role $role){
        return UserResource::collection($role->users);
    }

    public function usersedit(User $user){
        return view('admin.userEdit',[
            'user'=>$user,
            'roles'=>Role::all(),
            'goodMessage'=>false
        ]);
    }

    public function banned(User $user){
        $user->banned=!$user->banned;
        $user->save();
        return back();
    }



    public function update(Request $request, User $user)
    {
        $user->role_id = $request->data;
        $user->save();
        return new UserResource($user);
    }
}
