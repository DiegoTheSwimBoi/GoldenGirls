<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Post\StoragePostRequest;
use App\Http\Services\FileServices;
use App\Http\Services\LanguageServices;
use App\Http\Services\PostService;
use App\Models\Article;
use App\Models\Country;
use App\Models\Image;
use App\Models\Likes;
use App\Models\Post;
use App\Models\Topic;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;

class ArticleController extends Controller
{
    public function index($topic)
    {
        if (Gate::allows('admin')) {
            return view("post.index", ['posts' => Post::all()->where('topic_id', $topic), 'topic' => $topic]);
        }

        return redirect()->route('admin.login');
    }

    public function show(Post $post)
    {
        return view("post.show", ['post' => $post, 'contents' => $post->images, 'likes' => $post->likes[0], "data" => LanguageServices::langExport()]);
    }

    public function create()
    {
        if (Gate::allows('admin')) {
            return view("post.create", ['topics' => Topic::all(), 'countries' => Country::all()]);
        }
    }


    public function store(StoragePostRequest $request)
    {

        if (Gate::allows('admin')) {


            $post = Post::create([
                'title' => $request->title,
                'article'=>$request->article,
                'made_by'=>$request->by,
                'description'=>$request->description,
                'content'=> $request->get('content'),
                'facts'=>$request->get('facts'),
                'country_id'=> $request->country,
                'topic_id'=> $request->topic,
            ]);

            Likes::create([
               'likes'=>0,
                'post_id'=>$post->id
            ]);

            if ($request->file('images') !== null || $request->file('videos') !== null) {
                $pathContents = FileServices::inputFile($request->file('images'));
                $pathVideoes = FileServices::inputFile($request->file('videos'));


                if ($pathContents) {
                    foreach ($pathContents as $fileName) {
                        Image::create([
                            'image' => $fileName,
                            'type' => 'image',
                            'post_id' => $post->id
                        ]);
                    }
                }

                if ($pathVideoes) {
                    foreach ($pathVideoes as $fileName) {
                        Image::create([
                            'image' => $fileName,
                            'type' => 'video',
                            'post_id' => $post->id
                        ]);
                    }
                }

            }

            return redirect()->route('admin.post.topic', $request->get('topic'));
        }


    }


    public function edit(Post $post)
    {
        if (Gate::allows('admin')) {
            $content = Image::all()->where('post_id', $post->id);
            return view('post.edit', ['post' => $post, 'defaultStorage' => '/storage/', 'images' => $content->where('type', 'image'), 'videos' => $content->where('type', 'video'), 'topics' => $post->topic, 'country' => $post->country]);
        }
    }

    public function update(StoragePostRequest $request, Post $post)
    {
        if (Gate::allows('admin')) {

            $images = $request->get('deleteImage');
            $videos = $request->get('deleteVideo');

            if (!empty($images)) {
                foreach ($images as $image) {
                    Image::where('image', $image)->delete();
                    FileServices::deleteFile($image);
                }
            }

            if (!empty($videos)) {
                foreach ($videos as $video) {
                    FileServices::deleteFile($video);
                    Image::where('image', $video)->delete();
                }
            }

            $post->update([
                'title' => $request->title,
                'article'=>$request->article,
                'made_by'=>$request->by,
                'description'=>$request->description,
                'content'=> $request->get('content'),
                'facts'=>$request->get('facts'),
                'country_id'=> $request->country,
                'topic_id'=> $request->topic,
            ]);

            if ($request->file('images') !== null || $request->file('videos') !== null) {
                $pathContents = FileServices::inputFile($request->file('images'));
                $pathVideoes = FileServices::inputFile($request->file('videos'));


                if ($pathContents) {
                    foreach ($pathContents as $fileName) {
                        Image::create([
                            'image' => $fileName,
                            'type' => 'image',
                            'post_id' => $post->id
                        ]);
                    }
                }

                if ($pathVideoes) {
                    foreach ($pathVideoes as $fileName) {
                        Image::create([
                            'image' => $fileName,
                            'type' => 'video',
                            'post_id' => $post->id
                        ]);
                    }
                }

            }

            return redirect()->route('admin.post.topic', $request->get('topic'));
        }
    }

    public function delete(Post $post)
    {
        if (Gate::allows('admin')) {
            $images = Image::all()->where('post_id', $post->id);

            $topic = $post->topic_id;


            if (!empty($images)) {
                foreach ($images as $image) {
                    FileServices::deleteFile($image->image);
                    $image->delete();
                }
            }

            $likes = Likes::where('post_id', $post->id)->first();

            if ($likes) {
                $likes->delete();
            }

            $post->delete();


            return redirect()->route('admin.post.topic', $topic);
        }

    }
}
