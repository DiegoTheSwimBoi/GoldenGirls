<?php


namespace App\Http\Controllers;

use App\Http\Services\FileServices;
use App\Http\Services\LanguageServices;
use App\Http\Services\PostService;
use App\Models\Image;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Gate;
use App\Models\Country;
use App\Models\Topic;
use App\Models\Post;
use App\Models\Likes;

use App\Http\Requests\Post\StoragePostRequest;


class PostController extends Controller
{

    public static function updateCookie(){
        $lang='ru';
        if (Auth::user()) {
            $lang = Auth::user()->country->flag;
        }else {
            if(!isset($_COOKIE['country'])){
                setcookie('country', 'ru', time() + 3600, '/');
                $lang='ru';
            }else{
                $lang = $_COOKIE['country'];
            }

        }

        return $lang;
    }

    public function main()
    {
        $lang=self::updateCookie();
        return view("welcome", ["flags" => Country::all(), 'post' => LanguageServices::postExport($lang)['main'], "data" => LanguageServices::langExport($lang), 'lang' => $lang]);
    }

    public function creators()
    {
        $lang=self::updateCookie();
        return view('creators', ['data' => LanguageServices::langExport($lang), 'post' => LanguageServices::postExport($lang)['creators']]);
    }

    public function episodes()
    {
        $lang=self::updateCookie();
        $country=Country::where('flag',$lang)->first();
        $new_posts=Post::take(5)->latest()->get();
        $post=Post::where('country_id', $country->id)->where('topic_id', 2)->Paginate(6)->withQueryString();;
        if(request('search')){
            $post=Post::where('country_id', $country->id)->where('title','like',"%".request('search')."%")->Orwhere('content','like',"%".request('search')."%")->Paginate(6)
            ->withQueryString();
        
        
        }
        return view('category', ['posts' =>$post, 'data' => LanguageServices::langExport($lang), 'name'=>'episode','news'=>$new_posts]);
    }

    public function episode(Post $post)
    {
        $lang=self::updateCookie();
        return view("post", ["post" => $post, "data" => LanguageServices::langExport($lang)]);
    }


    public function characters()
    {
        $lang=self::updateCookie();
        $country=Country::where('flag',$lang)->first();
        $new_posts=Post::all()->take(5);
        $post=Post::where('country_id', $country->id)->where('topic_id', 1)->Paginate(6)->withQueryString();
        if(request('search')){
            $post=Post::where('country_id', $country->id)->where('title','like',"%".request('search')."%")->Orwhere('content','like',"%".request('search')."%")->Paginate(6)
            ->withQueryString();
        }
        return view('category', ['posts' => $post, 'data' => LanguageServices::langExport($lang),'name'=>'character','news'=>$new_posts]);
    }

    public function character(Post $post)
    {
        $lang=self::updateCookie();
        return view("post", ["post" => $post, "data" => LanguageServices::langExport($lang)]);
    }


    public function about()
    {
        $lang=self::updateCookie();
        return view('about', ['data' => LanguageServices::langExport($lang), 'post' => LanguageServices::postExport($lang)['about']]);
    }




    public function updateLang(Request $request)
    {
        setcookie('country', $request->country, time() + 3600, '/');
        return redirect()->route('welcome');
    }

}
