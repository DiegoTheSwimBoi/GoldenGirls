<?php

namespace App\Http\Controllers;

use App\Http\Requests\Comment\CommentRequest;
use App\Models\Comment;
use App\Models\Post;
use Illuminate\Support\Facades\Gate;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;

class CommentController extends Controller
{
    public function index(){

        $research=false;

        if(request('sort')){
            $research=request('sort')=="1"?true:false;
        }

        $set_sort=["Не опубликованные","Опубликованные"];

        if(Gate::allows('moderator')){
            return view("moderator.comment",['comments'=>Comment::with('user')->where('posted',$research)->Paginate(6)->
            withQueryString(),'sorts'=>$set_sort]);
        }
        return redirect()->route("welcome");
    }

    public function show(Comment $comment){
        if(Gate::allows('moderator')){
            return view("moderator.comment-show",['comment'=>$comment]);
        }
        return redirect()->route("welcome");
    }

    public function indexPosted(){
        if(Gate::allows('moderator')){
            return view("moderator.commentPosted",['comments'=>Comment::with('user')->where('posted',true)->Paginate(6)->withQueryString()]);
        }
        return redirect()->route("welcome");
    }

    public function update(Comment $comment){
        Comment::whereId($comment->id)->update([
            "posted"=>!$comment->posted
        ]);

        return redirect()->route("moderator.comments");
    }


    public function store(CommentRequest $request,Post $post){
        if(Auth::user()){
            $post->comments()->create([
                'comment'=>$request->get('comment'),
                'user_id'=>Auth::id()
            ]);

            return redirect()->back();
        }


        return redirect()->route("welcome");
    }

    public function delete(Comment $comment){
        if(Gate::allows('moderator')){
            $comment->delete();
            return redirect()->route("moderator.comments");
        }

        return redirect()->route("welcome");
    }




}
