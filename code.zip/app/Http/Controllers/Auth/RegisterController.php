<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Http\Services\LanguageServices;
use Illuminate\Http\Request;
use App\Http\Requests\Auth\RegisterRequest;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use App\Models\Country;

class RegisterController extends Controller
{
    public static function updateCookie()
    {
        $lang = 'ru';
        if (Auth::user()) {
            $lang = Auth::user()->country->flag;
        } else {
            if (!isset($_COOKIE['country'])) {
                setcookie('country', 'ru', time() + 3600, '/');
                $lang = 'ru';
            } else {
                $lang = $_COOKIE['country'];
            }

        }

        return $lang;
    }

    public function register()
    {
        $lang = self::updateCookie();
        Auth::logout();
        return view("auth.register", ['countries' => Country::all(), 'form' => LanguageServices::authExport($lang)['regin'],'data'=>LanguageServices::langExport($lang)['back']]);
    }

    public function registerStore(RegisterRequest $request)
    {

        if (Auth::attempt($request->only(['email', 'password']))) {
            return back()->withErrors([
                'errorRegister' => "Пароль или email уже есть в системе"
            ]);

        } else {
            User::create([
                    "name" => $request->input('name'),
                    "email" => $request->input('email'),
                    "password" => Hash::make($request->password),
                    "role_id" => 3,
                    "country_id" => $request->input('country'),
                    "banned" => false,
                ] + $request->only(['name', 'email', 'password']));

            Auth::attempt($request->only(['email', 'password']));
        }
        return redirect()->route('welcome');
    }

    public function reloadCaptcha()
    {
        return response()->json(['captcha' => captcha_img()]);
    }

}


