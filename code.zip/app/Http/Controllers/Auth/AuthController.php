<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Http\Services\LanguageServices;
use Illuminate\Http\Request;
use App\Models\User;
use App\Http\Requests\Auth\AuthRequest;
use Illuminate\Support\Facades\Auth;


class AuthController extends Controller
{
    public static function updateCookie(){
        $lang='ru';
        if (Auth::user()) {
            $lang = Auth::user()->country->flag;
        }else {
            if(!isset($_COOKIE['country'])){
                setcookie('country', 'ru', time() + 3600, '/');
                $lang='ru';
            }else{
                $lang = $_COOKIE['country'];
            }

        }

        return $lang;
    }


    public function login(){
        $lang=self::updateCookie();
        Auth::logout();
        return view('auth.login',['form'=>LanguageServices::authExport($lang)['auth'],'data'=>LanguageServices::langExport($lang)['back']]);
    }

    public function loginCheck(AuthRequest  $request){
        if (Auth::attempt($request->only(['email', 'password']),$request->has('remembered'))){
            $user=User::where('email',$request->email)->first();
            if(!$user->banned){
                $request->session()->regenerate();
                return redirect()->route('welcome');
            }
            return back()->withErrors([
                'banned'=>'К сожалению - ваш аккаунт был заблокирован...'
            ]);
        }

        return back()->withErrors([
            'email'=>'К сожалению у нас нет вашей почты...',
            'password'=>"Или не правильно введён пароль"
        ]);
    }


    public function logout(){
        Auth::logout();
        request()->session()->invalidate();
        request()->session()->regenerateToken();
        return redirect()->route('welcome');
    }

    public function user(){
        return view('auth.user');
    }
}
