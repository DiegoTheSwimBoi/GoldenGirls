<?php

namespace App\Http\Controllers;

use App\Models\Likes;
use Illuminate\Support\Facades\Auth;
use App\Http\Resources\LikeResource;

class LikesUserController extends Controller
{
    public function attachLike(Likes $like){
        if($like->user()->where('user_id', Auth::id())->exists()){
            $like->user()->detach(Auth::id());
            $like->update([
            'likes'=>$like->likes-1,
            ]);
            return new LikeResource($like);
        }else{
            $like->user()->attach(Auth::id());

            $like->update([
                'likes'=>$like->likes+1,
            ]);

            return new LikeResource($like);
        }
    }
}
