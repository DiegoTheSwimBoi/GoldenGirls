<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Topic;
use App\Models\Country;

class PostApiController extends Controller
{
    public function show(Country $country){
        return $country->topic;
    }
}
