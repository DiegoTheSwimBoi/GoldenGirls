<?php

namespace App\Http\Requests\Comment;

use Illuminate\Foundation\Http\FormRequest;

class CommentRequest extends FormRequest
{

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'comment'=>'max:150'
        ];
    }

    public function messages()
    {
        return [
            'comment'=>'<:attribute> должен быть меньше 150 символов'
        ];
    }

    public function attributes()
    {
        return [
            'comment'=>"Комментарий"
        ];
    }
}
