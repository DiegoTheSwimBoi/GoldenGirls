<?php

namespace App\Http\Requests\Post;

use Illuminate\Foundation\Http\FormRequest;

class StoragePostRequest extends FormRequest
{

    public function rules()
    {
        return [
            "title"=>['required','string','max:50'],
            "content"=>'required',
            "images" => 'array',
            "images.*" => 'image'
        ];
    }

    public function messages()
    {
        return [
            'required'=>"Поле <:attribute> должно быть заполнено",
            'min'=>"Поле <:attribute> должно быть больше 3 символов",
            'image'=>"Файлы <:attribute> должны быть типа image/jpeg,image/png,image/gif",
        ];
    }

    public function attributes()
    {
        return [
            'title'=>"Заголовок",
            'content'=>"Содержимое",
            'images.*' => "Картинки"
        ];
    }
}
