<?php

namespace App\Http\Requests\Auth;

use Illuminate\Foundation\Http\FormRequest;

class AuthRequest extends FormRequest
{
    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            "email" => 'required|email',
            "password" => ['required', 'min:8'],
        ];
    }

    public function messages()
    {
        return [
            'email' => '<:attribute> должен быть валидным',
            'password' => 'Неправильно заполнен <:attribute>'
        ];
    }

    public function attributes()
    {
        return [
            'email' => "E-mail",
            'password' => 'Пароль'
        ];
    }
}
