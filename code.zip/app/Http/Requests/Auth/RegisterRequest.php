<?php

namespace App\Http\Requests\Auth;

use Illuminate\Foundation\Http\FormRequest;

class RegisterRequest extends FormRequest
{
    public function rules()
    {
        return [
            "name"=>['required','string'],
            "email"=>['required','unique:users'],
            "password"=>['required','min:8','confirmed'],
            'captcha' => 'required|captcha',
        ];
    }

    public function messages()
    {
        return [
            'required'=>":attribute must be filled",
            'email.unique'=>':attribute has to be unique',
            'password.confirmed'=>':attribute-s are not same',
            'captcha'=>':attribute is invalid'
        ];
    }

    public function attributes()
    {
        return [
            "name"=>'Login',
            "email"=>'Email',
            "password"=>'Password',
            'captcha' =>'Captcha',
        ];
    }
}
