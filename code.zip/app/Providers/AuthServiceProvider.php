<?php

namespace App\Providers;

use Illuminate\Foundation\Support\Providers\AuthServiceProvider as ServiceProvider;
use Illuminate\Support\Facades\Gate;

class AuthServiceProvider extends ServiceProvider
{
    /**
     * The policy mappings for the application.
     *
     * @var array<class-string, class-string>
     */
    protected $policies = [
        // 'App\Models\Model' => 'App\Policies\ModelPolicy',
    ];

    /**
     * Register any authentication / authorization services.
     *
     * @return void
     */
    public function boot()
    {
        $this->registerPolicies();
        // Gate::define('edit-post',function($user,$post){
        //     return $user->id==$post->user_id;
        // });

        // Gate::define('delete-post',function($user,$post){
        //     return $user->id==$post->user_id;
        // });


        Gate::define('admin',function ($user,$defaultName='Администратор'){
            return $user->role->role==$defaultName;
        });


        Gate::define('moderator',function ($user,$defaultId=2){
            return $user->role_id==$defaultId;
        });


        Gate::define('guest',function ($user,$defaultId=1){
            return $user->role_id==$defaultId;
        });

        Gate::define('admin-moderator',function ($user,$defaultId=[1,2]){
            return in_array($user->role_id,$defaultId);
        });


        Gate::define('user-comment', function($user, $comment){
            return $user->id==$comment->user_id;
        });
    }
}

