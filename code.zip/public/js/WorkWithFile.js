let fileImage = document.getElementById("inputGroupFile02");
let imageDiv = document.getElementById("image");




if(fileImage){
    fileImage.addEventListener('change',function (event){
        let target=event.target;

        for (let i = 0; i < target.files.length; i++) {
            if(target.files[i] && target.files[i].type.includes('image')){
                imageDiv.innerHTML+=`<img src='${URL.createObjectURL(target.files[i])}' height="120" width="120" id="image" style="display: true; background-size: cover;"/>`;
                imageDiv.onload=function (){
                    URL.revokeObjectURL(target.src);
                    
                }
            }
        }
        
    })
}



