function getUsersRow({full_name,role,post_count,id}){
    return `
         <div class="d-flex justify-content-around">
             <div class="d-flex"><p>${full_name}</p>- ${role}  -
                  <p>${post_count}</p>
             </div>
             <a href="${id}" class="btn btn-primary">Подробно</a>
         </div>
    `;
}


