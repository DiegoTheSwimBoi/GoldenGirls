async function leavelike(route,data, _token) {
    let response = await fetch(route, {
        method: 'PATCH',
        headers: {
            'Content-Type': 'application/json; charset=UTF-8',
        },
        body: JSON.stringify({data,_token}),
    });
    return await response.json();
}

document.getElementById("like").addEventListener("submit", async (e)=>{
    e.preventDefault();
    let data = await leavelike("/leave/",document.querySelector(".like").id,"{{ csrf_token() }}");
    generateCount(data);
});

function generateCount({like}){
    document.getElementById("count").innerHTML=like;
}
