// async function getUsers(){
//     let response = await fetch(`{{route("admin.usersAll")}}`);
//     let data = await response.json();
//     console.log(data);
//     return data;
// }
