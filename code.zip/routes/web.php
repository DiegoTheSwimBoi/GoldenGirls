<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Admin\AdminController;
use App\Http\Controllers\Admin\ArticleController;
use App\Http\Controllers\Moderator\ModeratorController;
use App\Http\Controllers\Auth\RegisterController;
use App\Http\Controllers\Auth\AuthController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\LikesUserController;
use App\Http\Controllers\PostController;
use App\Http\Controllers\CommentController;
use Illuminate\Support\Facades\Artisan;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
| Thank you, laravel team!
|
*/


/*
| 02.20.22
*/

Route::get('/clear', function () {
    Artisan::call('cache:clear');
    Artisan::call('config:cache');
    Artisan::call('view:clear');
    Artisan::call('route:clear');
 
    return "Кэш очищен.";
});

Route::get('/',[PostController::class,'main'])->name("welcome");
Route::post('/language/update',[PostController::class,'updateLang'])->name('post.lang.update');

Route::get('/episodes',[PostController::class,'episodes'])->name("episodes");
Route::get('/characters',[PostController::class,'characters'])->name("characters");

Route::get('/episodes/{post}',[PostController::class,'episode'])->name("episode");
Route::get('/characters/{post}',[PostController::class,'character'])->name("character");

Route::get('/about',[PostController::class,'about'])->name('about');
Route::get('/creators',[PostController::class,'creators'])->name('creators');




Route::get("/login",[AuthController::class,'login'])->name("auth.index");
Route::post("/login",[AuthController::class,'loginCheck'])->name("login.check");

Route::get("/register",[RegisterController::class,'register'])->name("register.index");
Route::post("/register",[RegisterController::class,'registerStore'])->name("register.store");
Route::get("/reload-captcha",[RegisterController::class,'reloadCaptcha'])->name("register.reload");

Route::post("/comment/{post}/post",[CommentController::class, 'store'])->name("comment.store");
Route::patch("/leave/{like}",[LikesUserController::class,'attachLike'])->name('add-like');
Route::get("/user",[UserController::class, 'index'])->name('user');
Route::get("/user/comments",[UserController::class, 'comment'])->name('user.comments');
Route::delete("/user/comments/{comment}/delete",[UserController::class, 'delete'])->name('comment.delete');
Route::get("/user/like",[UserController::class, 'likes'])->name('user.likes');
Route::get("/user/settings",[UserController::class,'edit'])->name("user.edit");
Route::patch("/user/update/",[UserController::class,'update'])->name("user.update");
Route::get("/logout",[AuthController::class,'logout'])->name("logout");



/*
| 03.15.22 Created Moderator prefix
*/

Route::prefix('moderator')->name('moderator.')->group(function (){
    Route::get("/",[\App\Http\Controllers\Moderator\ModeratorController::class,'login'])->name('login');
    Route::post("/",[\App\Http\Controllers\Moderator\ModeratorController::class,'loginCheck'])->name('login.check');
    Route::middleware('can:moderator')->group(function (){
       Route::get("/dashboard",[\App\Http\Controllers\Moderator\ModeratorController::class,'dashboard'])->name("dashboard");

       Route::get("/users",[\App\Http\Controllers\Moderator\ModeratorController::class,'users'])->name("users");
       Route::patch('/users/banned/{user}', [\App\Http\Controllers\Moderator\ModeratorController::class, 'banned'])->name('banned');

       Route::get("/comments",[CommentController::class,"index"])->name("comments");
       Route::get("/comments/posted/",[CommentController::class,"indexPosted"])->name("comments.posted");
       Route::get("/comments/{comment}",[CommentController::class,"show"])->name("comments.show");
       Route::patch("/comments/{comment}",[CommentController::class,"update"])->name("comments.post");
       Route::delete("/comments/{comment}/delete",[CommentController::class,"delete"])->name("comments.delete");
       Route::get("/logout", [\App\Http\Controllers\Moderator\ModeratorController::class,'logout'])->name("logout");
    });
});

/*
| 02.25.22 Created Admin prefix
*/

Route::prefix('admin')->name('admin.')->group(function (){
    Route::get("/",[\App\Http\Controllers\Admin\AdminController::class,'login'])->name('login');
    Route::post("/",[\App\Http\Controllers\Admin\AdminController::class,'loginCheck'])->name('login.check');
    Route::middleware('can:admin')->group(function (){
        Route::get("/dashboard",[\App\Http\Controllers\Admin\AdminController::class,'dashboard'])->name("dashboard");

        Route::get("/users",[\App\Http\Controllers\Admin\AdminController::class,'users'])->name("users");
        Route::get("/users/all",[\App\Http\Controllers\Admin\AdminController::class,'usersall'])->name('usersall');
        Route::get('/users/filter/{role}',[\App\Http\Controllers\Admin\AdminController::class,'usersfilter']);
        Route::get('/users/edit/{user}',[\App\Http\Controllers\Admin\AdminController::class,'usersedit'])->name("usersedit");
        Route::patch('/users/update/{user}', [\App\Http\Controllers\Admin\AdminController::class, 'update'])->name('usersupdate');
        Route::patch('/users/baned/{user}',[\App\Http\Controllers\Admin\AdminController::class, 'banned'])->name('banned');
        Route::get("/save/admin",[\App\Http\Controllers\Admin\AdminController::class,'save_admin'])->name("save.admin");
        Route::get("/save/post",[\App\Http\Controllers\Admin\AdminController::class,'save_post'])->name("save.post");

        Route::get("/posts/index/{topic}",[ArticleController::class,'index'])->name("post.topic");
        Route::get("/posts/{post}/show",[ArticleController::class,'show'])->name('post.show');
        Route::get("/posts/add",[ArticleController::class,'create'])->name('post.add');
        Route::post("/post/add",[ArticleController::class,'store'])->name('post.store');
        Route::get("/post/{post}/edit",[ArticleController::class,'edit'])->name('post.edit');
        Route::patch("/post/{post}",[ArticleController::class,'update'])->name('post.update');
        Route::delete("/post/{post}",[ArticleController::class,'delete'])->name('post.destroy');



        Route::get("/logout",[\App\Http\Controllers\Admin\AdminController::class,'logout'])->name("logout");
    });
});
