@extends('layouts.app')


@section("title",$post->title)


@section("content")
    <div class="d-flex justify-content-center align-content-center">
        <div class="row w-100 mt-5">
            <div class="col-sm-2 mb-5 phone-version">
                <div class="card col-3" style="width: 18rem; background-color: rgb(39, 35, 35);">
                    <img src="/storage/{{$post->images[0]->image}}" alt="{{$post->title}}" height="300"
                         class="card-img-top">
                    <div class="card-body text-white">
                        <h3 class="card-title text-center">{{$post->title}}</h3>
                        <hr>
                        <div>{!! $post->article !!}</div>
                        <small>{{$post->made_by}}</small>
                    </div>
                </div>
            </div>

            <div class="gap-2 col-sm-9 text-white" style="background-color: rgb(39, 35, 35); ">
                <div class="mt-3 p-3" style="font-size: large;">
                    <div class="row">
                    <h1 class="col-6">{{$post->title}}</h1>
                    <a href="javascript:history.back()" class="col-1 mt-3 text-decoration-none hover pink">{{$data['back']}}</a>
                    <a href="{{route('welcome')}}" class="col-2 mt-3 text-decoration-none hover pink">{{$data['main']}}</a>
                    </div>
                        <hr>
                    <div class="w-75">
                        {{$post->description}}
                        <hr>
                    </div>
                    <div class="mt-3">{!! $post->content !!}</div>
                    <h3 class="mt-3">{{$data['facts']}}</h3>
                    <hr>
                    <div class="p-2">
                        <ul>{!! $post->facts !!}</ul>
                    </div>
                    <h3 class="mt-3">{{$data['gallery']}}</h3>
                </div>
                <hr>
                <div class="p-3 row">
                    @foreach($post->images as $image)
                    <img src="{{$image->image_full}}" class="col-sm-3 mt-2" style="object-fit: cover;" alt="{{$post->title}}" data-bs-toggle="modal" data-bs-target="#modalDestroy">
                    @endforeach

{{--                        <a class="btn btn-danger" >Удалить</a>--}}

                </div>
                <div class="mt-5">@include("inc.post-footer")</div>
                @include('inc.modal_gallery')

            </div>

            <div class="col-sm-2 pc-version">
                <div class="card col-3" style="width: 18rem; background-color: rgb(39, 35, 35);">
                    <img src="/storage/{{$post->images[0]->image}}" alt="{{$post->title}}" height="300"
                         class="card-img-top">
                    <div class="card-body text-white">
                        <h3 class="card-title text-center">{{$post->title}}</h3>
                        <hr>
                        <div>{!! $post->article !!}</div>
                        <small>{{$post->made_by}}</small>
                    </div>
                </div>
            </div>

        </div>
    </div>

@endsection()
@section('scripts')
    <script>
        async function leavelike(route, _token) {
            let response = await fetch(route, {
                method: 'PATCH',
                headers: {
                    'Content-Type': 'application/json; charset=UTF-8',
                },
                body: JSON.stringify({_token}),
            });
            return await response.json();
        }

        document.getElementById("like").addEventListener("submit", async (e) => {
            e.preventDefault();
            let data = await leavelike("{{route('add-like',$post->likes[0])}}", "{{ csrf_token() }}");
            generateCount(data);
            console.log(data);
        });

        function generateCount({like}) {
            document.getElementById("count").innerHTML = like;
            let likeButton = document.querySelector('.like');
            if (likeButton.classList.contains('no-like')) {
                likeButton.classList.remove('no-like');
                likeButton.classList.add('has-like');
            } else {
                likeButton.classList.remove('has-like');
                likeButton.classList.add('no-like');
            }
        }
    </script>

@endsection()
