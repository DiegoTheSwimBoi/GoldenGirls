@extends('layouts.app')


@section("title",$post['title'])


@section("content")
    <div class="container-body text-light mt-5">

        <div class="logo"></div>

        <div class="container text-center">
            <div class="row">
                <a href="{{route('welcome')}}" class="col-md-3 text-decoration-none hover pink">Golden Girls</a>
                @foreach($data['header'] as $key=>$nav)
                    <a href="{{route($key)}}" class="col-md-2 text-decoration-none hover pink">{{$nav}}</a>
                @endforeach
            </div>
        </div>
        <div class="p-md-5">
            <hr class="logo-line">
        </div>

        <div class="container text-center">
            <div class="row d-flex">
                <h3>{{$post['title']}}</h3>
                <div class='content'>
                    @foreach($post['content'] as $content)
                        <div class='mt-4'>
                            <p class='text-start' style="font-size: large;">{{$content}}</p>
                        </div>
                    @endforeach
                </div>
            </div>
        </div>

        <div class="mt-5">
            @include("inc.footer")
        </div>
    </div>
@endsection()
