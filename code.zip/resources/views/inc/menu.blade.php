<div class="logo"></div>
<div class="container text-center">
    <div class="row">
        @foreach($data['header'] as $key=>$nav)
            <a href="{{route($key)}}" class="col-md-3 mb-5 text-decoration-none hover pink">{{$nav}}</a>
        @endforeach
        @auth
            <a href="{{route('user')}}" class="col-md-6 mt-5 text-decoration-none hover text-warning">{{Auth()->user()->name}}</a>
            <a href="{{route('logout')}}" class="col-md-6 mt-5 text-decoration-none hover pink">{{$data['logout']}}</a>
        @endauth
    </div>
