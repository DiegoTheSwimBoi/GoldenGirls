@if(!empty($post->comments))
<div class="mt-5 mb-5">
    <h3>Комментарии</h3>
    <hr>
</div>
    @auth()
        <div>
            <form action="{{route('comment.store',$post)}}" method="post">
                @csrf
                @method('POST')
                <div class="form-floating mt-4">
                <textarea name="comment" class="form-control" placeholder="Leave a comment here"
                          id="floatingTextarea" style="height: 180px; width: 100%; resize: none;"></textarea>
                    <label for="floatingTextarea" class="text-muted">Оставьте свой комментарий</label>
                </div>
                <div class="mt-3">
                    <button name="post-button" class="btn btn-primary btn-lg">Отправить</button>
                </div>
            </form>
        </div>
    @endauth
    <div class="mt-5 ">

        @foreach($post->comments as $comment)
            @if($comment->posted)

                <div>
                    <div class="d-flex justify-content-between flex-wrap">
                        <span>{{$comment->user->name}} - {{$comment->date_comment_humans}}</span>
                        @canany(['user-comment'],$comment)
                            <a href="#" class="btn-close" aria-label="Close"></a>
                            {{--                        {{route('comment.delete',[$post,$comment])}}--}}
                        @endcanany
                    </div>
                    <p class="text-muted">{{$comment->user->role->role}}</p>
                    <p>{{$comment->comment}}</p>
                </div>
            @endif
        @endforeach

    </div>



@endif
