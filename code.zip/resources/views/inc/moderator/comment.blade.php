<div class="card bg-success text-white h-100">
    <div class="card-header d-flex justify-content-around">
    {{$comment->user->name}} - {{$comment->user->role->role}}
    <form action="{{route('moderator.comments.delete',$comment)}}" method="post">
        @csrf
        @METHOD('DELETE')
    <button class="btn-close" aria-label="Close"></button>
    </form>
    </div>
    <div class="card-body d-flex flex-column justify-content-between text-center">
        <p class="card-title">Комментарий:</p>
        <h6 class="card-text">{{$comment->short_comment}}</h6>
    </div>
    <div class="card-footer">
        <div class="text-center">{{$comment->date_comment_humans}}</div>
    </div>
    <div class="card-footer">
        <form action="{{route('moderator.comments.post',$comment)}}" method="post" class="d-flex justify-content-between">
            @csrf
            @METHOD('PATCH')
            <button class="btn text-decoration-none text-white p-0">{{!$comment->posted?"Опубликовать":"Заблокировать"}}</button>
            <a href="{{route('moderator.comments.show',$comment)}}" class="text-decoration-none text-white">Подробно</a>
        </form>
    </div>
</div>
