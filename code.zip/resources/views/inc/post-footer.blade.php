<div class="text-end">
    <div class="p-5" style="font-size: 20px;">
        <form id="like" method="post">
            @csrf
            @method("PATCH")
            <button type="submit" id="{{Auth::id()}}" class="btn like {{$post->likes[0]->like_class}}"
                    style="font-size: 21px;" @guest() disabled @endguest></button>
            <span id="count">{{$post->likes[0]->likes}}</span>
        </form>
    </div>
</div>
@guest()
    <div class="text-info text-center"><a href="{{route('auth.index')}}"
                                          class="text-decoration-none hover pink">{{$data['login']}}</a></div>
@endguest

<div class=" p-5  mb-5">
    @auth()
        <div class="text-info text-center">
            <a href="{{route('user')}}" class="text-decoration-none hover text-warning">{{$data['user']['login']}}</a>
        </div>
    @endauth
    @include('inc.comments')
</div>
<div class="p-5">
    <hr>
    <div>
        <div class="container text-center">
            <div class="row d-flex">
                @foreach($data['header'] as $key=>$nav)
                    <a href="{{$key}}" class="col-md-3 text-decoration-none hover pink">{{$nav}}</a>
                @endforeach
            </div>
        </div>
        <div class="d-flex justify-content-between flex-wrap mt-5">
            <a href="{{route('welcome')}}" class="text-decoration-none text-white">Golden Girls</a>            @foreach($data['footer'] as $text)
                <p>{{$text}}</p>
            @endforeach
            <a href="{{route('about')}}" class="text-decoration-none text-white"></a>
        </div>
    </div>
</div>
