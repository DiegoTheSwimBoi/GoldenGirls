@guest()
    <div class="text-info text-center"><a href="{{route('auth.index')}}"
                                          class="text-decoration-none hover pink">{{$data['login']}}</a></div>
@endguest

<div class=" p-5  mb-5">
    @auth()
        <div class="text-info text-center">
            <a href="{{route('user')}}" class="text-decoration-none hover text-warning">{{$data['user']['login']}}</a>
        </div>
    @endauth
</div>
<div class="p-5">
    <hr>
    <div>
        <div class="container text-center">
            <div class="row d-flex">
                @foreach($data['header'] as $key=>$nav)
                    <a href="{{$key}}" class="col-md-3 mb-5 text-decoration-none hover pink">{{$nav}}</a>
                @endforeach
            </div>
        </div>
        <div class="d-flex justify-content-between flex-wrap mt-5">
            <a href="{{route('welcome')}}" class="text-decoration-none hover pink">Golden Girls</a>
            @foreach($data['footer'] as $text)
                <p class="mb-5">{{$text}}</p>
            @endforeach
            <a href="{{route('about')}}" class="text-decoration-none text-white">{{$data['more-about']['about']}}</a>
        </div>
    </div>
</div>
