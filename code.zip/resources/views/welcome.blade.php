@extends('layouts.app')


@section("title",$post['title'])


@section("content")
    <div class="d-flex align-items-stretch">
        <div class="characters"></div>
    </div>
    <div class="container-body text-light">
            @include('inc.menu')
            @guest()
            <div class="mt-5">
                <form method="post" action="{{route('post.lang.update')}}">
                    @csrf
                    @method('POST')
                    <div class="row">
                        @foreach($flags as $flag)
                            <div class="col-md-3">
                                <label for="{{$flag->flag}}">
                                    <input type="radio" onchange="this.form.submit()" value="{{$flag->flag}}" name="country" style="display: none;"
                                           id="{{$flag->flag}}" {{$flag->flag==$lang?'checked':''}}>
                                    <img src="{{$flag->flag_img}}" alt="{{$flag->flag}}">
                                </label>
                            </div>
                        @endforeach
                    </div>
                </form>
            </div>
            @endguest
        </div>
        <div class="p-md-5">
            <hr class="logo-line">
        </div>
        <div class="container text-center">
            <div class="title text-center "><h1>{{$post['about-show-title']}}</h1></div>
            <div class="flex-content mt-5">
                @foreach($post['about-show'] as $section)
                    <div>
                        <p class="text-start">{{$section}}</p>
                    </div>
                @endforeach
            </div>
            <div class="text-end">
                <div class="p-5">
                    <a href="{{route('creators')}}"
                       class="text-decoration-none hover pink">{{$data['more-about']['show']}}
                    </a>
                </div>
            </div>
        </div>
        <div class="mt-5 mb-5">
            @foreach($post['characters'] as $key=>$section)
                @if($key==1)
                    <div class="d-flex justify-content-around flex-wrap">@endif
                        <div class="{{$section['class']}}">
                            <img src="{{asset($section['img'])}}"
                                 alt="{{$section['name']}}"
                                 class="border border-5 border-white rounded-circle shadow p-3 mb-5 bg-dark rounded"/>
                            <p style="width: 20rem;">{{$section['info']}}</p>
                            <p>{{$section['name']}}</p>
                        </div>
                        @if($key==2)</div>
                @endif
            @endforeach
            <div class="text-end">
                <div class="p-5">
                    <a href="{{route('characters')}}"
                       class="text-decoration-none hover pink">{{$data['more-about']['character']}}</a>
                </div>
            </div>
        </div>
        <div class="border-rectangle"></div>
        <div class="pink-rectangle">
            <div class="text-center">
                <video width="640" height="512" controls="controls" class="mt-5" id="video">
                    <source src="{{$post['content']['path']}}/pilot.mp4" type='video/mp4'
                            id="source">
                    {{$post['content']['no-video']}}
                </video>

                <div class="p-md-5 d-flex justify-content-center align-content-center gap-3 flex-wrap">
                    @foreach($post['content']['image'] as $key=>$image)
                        <div>
                            <label><input type="radio" name="episode" id="episode" style="display:none;"
                                          value="{{$post['content']['path']}}/{{$image}}.mp4"><img
                                    src="{{$post['content']['path']}}/{{$image}}.png"
                                    height="180" width="250"
                                    alt="Golden girls moments - {{$key}}"
                                    class="rounded shadow p-1 mb-5"
                                ></label>
                            <p class="text-dark" style="font-size: large; font-weight: bolder;">{{$key}}</p>
                        </div>
                    @endforeach
                </div>
            </div>
            <div class="text-end">
                <div class="p-5">
                    <a href="{{route('episodes')}}"
                       class="text-decoration-none hover-black black">{{$data['more-about']['episode']}}</a>
                </div>
            </div>
        </div>
    </div>
    <div class="border-rectangle"></div>
    <div class="container-body text-light">
        <div class="p-5 mt-8 mb-8">
            <h2 class="text-center">{{$post['award-title']}}</h2>
            <div style="margin-top: 5rem; font-size: 18px;">
                @foreach($post['award'] as $section)
                    <div class="d-flex justify-content-center content-center">
                        <p>{{$section['title']}}</p>
                        <p>{{$section['name']}}</p>
                    </div>
                    <div class="p-md-5">
                        <hr class="award-line">
                    </div>
                @endforeach
            </div>
        </div>
        @include("inc.footer")
    </div>

@endsection()
@section('scripts')
    <script>
        let episodes = document.querySelectorAll("#episode");
        episodes.forEach(episode => {
            episode.addEventListener("click", function (e) {
                document.getElementById("source").src = e.target.value;
                document.getElementById("video").load();
                document.getElementById("video").scrollIntoView();
            })
        });

    </script>

@endsection()
