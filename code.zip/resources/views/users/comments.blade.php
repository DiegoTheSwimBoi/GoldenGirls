@extends('layouts.user')


@section("title","Пользователь")
@section("content")
<div class="card mb-3 mt-5 p-5">
    <p>{{$user->name}}</p>
    <div>
    <p>Комментарие, которые вы написали:  {{$user->comments->count()}}</p>
    <hr>
    <ul class="list-group">
    @foreach($comments as $comment)
        <li class="list-group-item">
        <div class="d-flex justify-content-between">
             <div class="d-flex gap-3">
             <p class="{{$comment->banned?'text-success':'text-danger'}}">{{$comment->banned?"Опубликован":"Не опубликован"}}</p>
             <p>{{$user->name}}</p>- {{$comment->short_comment}}
             </div>
             <form action="{{route('comment.delete',$comment)}}" method="POST">
                @csrf
                @METHOD('DELETE')
             <button class="btn btn-danger">Удалить</button>
             </form>
         </div>
        </li>
        @endforeach
    </ul>
</div>
</div>
@endsection()
