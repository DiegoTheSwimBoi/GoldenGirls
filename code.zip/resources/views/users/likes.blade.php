@extends('layouts.user')


@section("title","Пользователь")
@section("content")
    <div class="card mb-3 mt-5 p-5">
        <p>{{$user->name}}</p>
        <div>
            <p>{{$data['user']['posts-liked']}} {{count($likes)}}</p>
            <hr>
            <ul class="list-group">
                @foreach($likes as $like)
                    <li class="list-group-item">
                        <div class="d-flex justify-content-between">
                            <div class="d-flex gap-3">
                                <p>{{$like->title}}</p>
                            </div>
                        </div>
                    </li>
                @endforeach
            </ul>
        </div>
    </div>
@endsection()
