@extends('layouts.user')


@section("title","Пользователь")
@section("content")
    <div class="card mb-3 mt-5 p-5">
        <form method="post" action="{{route('user.update')}}">
            @csrf
            @method("PATCH")
        <div class="input-group mb-3">
            <input type="text" class="form-control" name="name" value="{{$user->name}}" placeholder="{{$data['user']['setting']['name']}}" aria-label="Username" aria-describedby="basic-addon1">
            <input type="text" value="{{$user->name}}"  class="form-control" readonly>
        </div>
            <div class="input-group mb-3">
                <input type="text" class="form-control" name="email" value="{{$user->email}}" placeholder="@email" aria-label="Username" aria-describedby="basic-addon1">
                <input type="text" name="email_old" value="{{$user->email}}" class="form-control" readonly>
            </div>
        <div class="input-group mb-3">
            <input type="password" name="password" class="form-control" placeholder="{{$data['user']['setting']['newPassword']}}" aria-label="Username" aria-describedby="basic-addon1">
        </div>
        <div class="input-group mb-3">
            <input type="password" class="form-control" name="password_confirmation" placeholder="{{$data['user']['setting']['oldPassword']}}" aria-label="Username" aria-describedby="basic-addon1">
        </div>

        <button class="btn btn-dark w-100">{{$data['user']['setting']['update']}}</button>
        </form>
    </div>
@endsection()
