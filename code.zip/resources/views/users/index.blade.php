@extends('layouts.user')


@section("title","Пользователь")
@section("content")
<div class="card mb-3 mt-5 p-5">
    @include("inc.error")
    <p>{{$user->name}}</p>
    <div>
    <p>{{$data['user']['comments-posted']}}  {{$user->comments->count()}}</p>
    <div class="progress">
  <div class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar" aria-valuenow="{{$user->comments->count()}}" aria-valuemin="0" aria-valuemax="100" style="width: {{$user->comments->count()}}%"></div>
</div>
</div>
<div class="mt-5"><p>{{$data['user']['posts-liked']}}  {{$like}}</p>
    <div class="progress">
  <div class="progress-bar progress-bar-striped progress-bar-animated bg-danger" role="progressbar" aria-valuenow="{{$like}}" aria-valuemin="0" aria-valuemax="100" style="width: {{$like}}%"></div>
</div>
</div>
</div>
@endsection()
