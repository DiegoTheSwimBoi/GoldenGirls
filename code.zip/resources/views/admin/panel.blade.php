@extends('layouts.admin')

@section("content")
<div>
    <p class="display-6">Привет, {{$admin->name}}- {{$admin->role->role}}</p>
    <div class="d-flex justify-content-evenly flex-wrap mt-5">
    </div>
</div>
@endsection()
