@extends('layouts.app')


@section("title","register")
@section("content")
<div class="formflex">
<div class="card offset-4 col-4 mt-lg-5 bg-dark bg-gradient p-2">
<div class="card-body">
    <form method="post" action="{{route('admin.login.check')}}">
        @csrf
        <div class="input-group mb-3">
            <input type="email"  name="email" class="form-control @error('email') is-invalid @enderror" placeholder="Введите email" aria-label="Username" aria-describedby="basic-addon1">
        </div>

        @error('email')
        <p class="text-danger">{{$message}}</p>
        @enderror

        <div class="input-group mb-3">
            <input type="password"  name="password" class="form-control @error('password') is-invalid @enderror" placeholder="Введите пароль" aria-label="Username" aria-describedby="basic-addon1">
        </div>

        @error('password')
        <p class="text-danger">{{$message}}</p>
        @enderror

        <button class="w-100 btn btn-lg text-light bg-primary" type="submit">Войти</button>

        @error('email')
        <p class="text-danger">{{$message}}</p>
        @enderror
    </form>
</div>
</div>
</div>
@endsection()
