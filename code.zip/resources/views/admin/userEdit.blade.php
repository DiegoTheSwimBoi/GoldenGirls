@extends('layouts.admin')
@section('title', 'user-edit')
@section('content')
    <div class="container">
        <h2>{{$user->full_name}}</h2>
        <form id="userEdit" method="post">
            @csrf
            @method('PATCH')
            <div class="input-group mb-4">
                <span class="input-group-text" id="inputGroup-sizing-default">{{$user->name}}</span>
                <select id="selectRole" class="form-select" aria-label=".form-select-sm example">
                @foreach($roles as $role)
                    <option value="{{$role->id}}" {{$role->id==$user->role_id?'selected':''}}>{{$role->role}}</option>
                @endforeach
                </select>
                <label class="input-group-text" for="selectRole"><button type="submit" class="btn btn-sm">Обновить</button></label>
            </div>
                <div class="" id="sucess-box" role="alert">
                   <p id="sucess-text"></p> 
                </div>
        </form>
        <form method="POST" action="{{route('admin.banned',$user)}}">
            @csrf
            @method('PATCH')
            <button class="btn btn-primary">{{$user->banned?"Разблокировать":"Заблокировать"}}</button>
        </form>
    </div>
@endsection
@push('child-scripts')
    <script>

        async function updateUser(route, data, _token) {
            document.getElementById('sucess-box').className="";
            document.getElementById('sucess-text').innerHTML="";
            let response = await fetch(route, {
                method: 'PATCH',
                headers: {
                    'Content-Type': 'application/json; charset=UTF-8',
                },
                body: JSON.stringify({data, _token}),
            });
            return await response.json();
        }

        document.getElementById('userEdit').addEventListener('submit', async (e) => {
            //запрет на работу по умолчанию
            e.preventDefault();
            let data = await updateUser("{{route('admin.usersupdate', $user)}}", selectRole.value, "{{ csrf_token() }}");
            document.getElementById('sucess-text').innerHTML="Обновление произошло удачно.";
            document.getElementById('sucess-box').className=" alert alert-success alert-dismissible fade show";
        });
    </script>
@endpush
