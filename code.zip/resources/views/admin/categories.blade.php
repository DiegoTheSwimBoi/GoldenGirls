@extends('layouts.admin')


@section("title","Категории")

@section("content")
    <h1>Категории</h1>
    <hr>

        @if(!empty($categs))
            @foreach($categs as $cat)
                <div class="card bg-{{$cat->style}} mt-5" style="width: 18rem;">
                    <div class="card-body">
                        <h5 class="card-title">{{$cat->name}}</h5>
                        </div>
                </div>
            @endforeach
        @else
            <li class="list-group-item">Список пуст</li>
        @endif
@endsection()
