<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Golden Girls" />

    <title>@yield('title')</title>
    <!--Styles-->
    <link rel="shortcut icon" href="{{asset('/storage/logo/icon.ico')}}" type="image/x-icon">
    <link href="{{asset('/css/bootstrap.min.css')}}" rel="stylesheet">
    <link href="{{asset('/css/style.css')}}" rel="stylesheet">
    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">
    @guest()
        <style>
            body{
                background-color: #FABCFF;
            }

            .border-rectangle{
                background: #af83b2;
            }

            .pink-rectangle{
                background: #fcd6ff;
            }
        </style>
    @endguest

    @auth()
        <style>
            body{
                background-color: #fffabc;
            }

            .border-rectangle{
                background: #ccc896;
            }

            .pink-rectangle{
                background: #fffbd0;
            }

        </style>
    @endauth
</head>
<body class="antialiased">

<div class="cont">
    @yield('content')
</div>

<script src="{{asset('/js/bootstrap.min.js')}}"></script>
<script src="{{asset('/js/bootstrap.min.js')}}"></script>
@yield('scripts')
</body>

</html>
