@extends('layouts.moderator')

@section('title',"Комментарии")

@section("content")
    <div>
        <form class="d-flex gap-3">
            <select class="form-select" name="sort">
                @foreach($sorts as $key=>$sort)
                    <option value="{{$key}}" {{$key==request('sort')?"selected":""}}>{{$sort}}</option>
                @endforeach
            </select>
            <button class="btn btn-primary">Отсортировать</button>
        </form>
    <div class="mt-5">{{$comments->onEachSide(1)->links()}}</div>
        <div class="container mt-5">
            <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-lg-3 g-3">

        @foreach($comments as $comment)
            <div>@include('inc.moderator.comment')</div>
        @endforeach
            </div>
        </div>
    </div>
@endsection
