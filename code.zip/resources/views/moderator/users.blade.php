@extends('layouts.moderator')


@section("title","hello blade php")


@section("content")
    <div>
        <p id="countUsers">Кол-во пользователей: {{count($users)}}</p>
    </div>
    <ul class="list-group" id="list">
        @foreach($users as $user)
        <li class="list-group-item">
        <div class="d-flex justify-content-between">
             <div class="d-flex"><p>{{$user->name}}</p>- {{$user->role->role}}  -
                  <p>{{count($user->comments)}} комментариев</p>
             </div>
             <form action="{{route('moderator.banned',$user)}}" method="POST">
                @csrf
                @METHOD('PATCH')
             <button class="btn btn-danger">{{$user->banned?"Разблокировать":"Заблокировать"}}</button>
             </form> 
         </div>
        </li>
        @endforeach
    </ul>
@endsection()

