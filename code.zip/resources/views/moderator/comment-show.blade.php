@extends('layouts.moderator')

@section('title',"Комментарии")

@section("content")
        <div class="container mt-5">
            <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-lg-3 g-3">

        
            <div>
                <p>{{$comment->user->name}} - {{$comment->user->role->role}}</p>
<div class="d-flex justify-content-around">
                <form action="{{route('moderator.comments.delete',$comment)}}" method="post">

                @csrf
                @METHOD('DELETE')
                <button class="btn-close" aria-label="Close"></button>
                </form>
                <form action="{{route('moderator.comments.post',$comment)}}" method="post" class="d-flex justify-content-between">
            @csrf
            @METHOD('PATCH')
            <button class="btn text-decoration-none p-0">{{!$comment->posted?"Опубликовать":"Заблокировать"}}</button>
            <a href="{{route('moderator.comments.show',$comment)}}" class="text-decoration-none text-white">Подробно</a>
            </form>
</div>
                <div class="card-body">
                    <p>{{$comment->comment}}</p>
                </div>
                
            </div>
        
            </div>
        </div>
    </div>
@endsection