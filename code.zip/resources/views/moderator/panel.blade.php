@extends('layouts.moderator')
@section("title","register")
@section("content")
    <p class="display-4"> Здравствуй, {{$moderator->name}} </p>
    <button class="btn" id="like">&#129293;</button>
{{--    <button class="btn" id="like">&#128155;</button>--}}

    <script>
        document.getElementById("like").addEventListener('click',function (e){
            e.target.innerHTML="&#128155;";
        });
    </script>

@endsection()
