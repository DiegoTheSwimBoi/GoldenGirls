@extends('layouts.app')


@section("title","register")
@section("content")
    <div class="mt-5"><a href="javascript:history.back()" class="btn btn-primary">{{$data}}</a></div>
<div class="card offset-4 col-4 mt-5">
<div class="card-header text-center">
    {{$form['regin']}}
    </div>
    <div class="card-body">
    <form method="post" action="{{route('login.check')}}">
    @csrf
    <div class="input-group mb-3">
                <input type="email"  name="email" class="form-control @error('email') border border-danger @enderror" value="{{old('email')}}" placeholder="{{$form['email']}}" aria-label="Username" aria-describedby="basic-addon1">
            </div>

            @error('email')
            <p class="text-danger">{{$message}}</p>
            @enderror

            <div class="input-group mb-3">
                <input type="password"  name="password" class="form-control @error('password') border border-danger @enderror"  placeholder="{{$form['password']}}" aria-label="Username" aria-describedby="basic-addon1">
            </div>

            @error('password')
            <p class="text-danger">{{$message}}</p>
            @enderror

        <div class="mb-3">
        <label><input type="checkbox" name="remembered" value="{{old('remembered')?'checked':''}}"> {{$form['remember']}}</label>
        </div>
            <div class="row">
                <div class="w-50 col-md-6">
                    <a href="{{route('register.index')}}" class="w-100 btn btn-secondary">{{$form['no-account']}}</a>
                </div>
               <div class="w-50 col-md-6">
                   <button type="submit" class="w-100 btn btn-primary">{{$form['regin']}}</button>
               </div>

        </div>

        @error('email')
        <p class="text-danger">{{$message}}</p>
        @enderror
    </form>
    </div>
</div>
@endsection()
