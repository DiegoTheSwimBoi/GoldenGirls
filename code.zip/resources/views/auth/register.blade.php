@extends('layouts.app')


@section("title","register")
@section("content")
<div class="mt-5"><a href="javascript:history.back()" class="btn btn-primary">{{$data}}</a></div>
<div class="card offset-4 col-4 mt-5">
    <div class="card-body bg-dark text-light ">
        <form method="post" action="{{route('register.store')}}">
            @csrf
			@method('POST')

            <div class="input-group">
                <input type="text" name="name" value="{{old('name')}}" class="form-control @error('name') is-invalid border border-danger @enderror" placeholder="{{$form['login']}}" aria-label="Username" aria-describedby="basic-addon1">
            </div>
            <small>{{$form['small']['required']}}</small>

            @error('name')
            <p class="text-danger">{{$message}}</p>
            @enderror

            <div class="input-group mt-3">
                <input type="email"  name="email" value="{{old('email')}}" class="form-control @error('email') is-invalid border border-danger @enderror" placeholder="{{$form['email']}}" aria-label="Username" aria-describedby="basic-addon1">
            </div>
            <small>{{$form['small']['required']}}</small>

            @error('email')
            <p class="text-danger">{{$message}}</p>
            @enderror


            <div class="input-group mt-3">
                <input type="password"  name="password" class="form-control @error('password') is-invalid border border-danger @enderror" placeholder="{{$form['password']}}" aria-label="Username" aria-describedby="basic-addon1">
            </div>
            <small>{{$form['small']['required']}} и {{$form['small']['password']}}</small>

            @error('password')
            <p class="text-danger">{{$message}}</p>
            @enderror

            <div class="input-group mt-3">
                <input type="password"  name="password_confirmation" class="form-control @error('password_confirmation') is-invalid  border border-danger @enderror" placeholder="{{$form['password_repeat']}}" aria-label="Username" aria-describedby="basic-addon1">
            </div>

            @error('password_confirmation')
            <p class="text-danger">{{$message}}</p>
            @enderror


            <div class="form-group mt-4 mb-4">
                <div class="captcha">
                    <span class="w-100" id="captcha-span">{!! captcha_img() !!}</span>
                    <button type="button" class="btn btn-danger reload" id="reload">
                        &#x21bb;
                    </button>
                </div>
            </div>

            <div class="form-group mt-4">
                <input id="captcha" type="text" class="form-control  @error('captcha') is-invalid border border-danger @enderror" placeholder="{{$form['captcha']}}" name="captcha">
            </div>
            <small>{{$form['small']['required']}}</small>

            @error('captcha')
            <p class="text-danger">{{$message}}</p>
            @enderror

            <div class="input-group  mt-3">
            <select class="form-select text-light bg-dark" name="country" id="lang">
                    @foreach($countries as $country):
                        <option value="{{$country->id}}" {{$country->id==old('country')?'selected':''}}>{{$country->flag}}</option>
                    @endforeach
            </select>
            </div>
            <small>{{$form['small']['country']}}</small>

            <div class="w-100 mt-3">
               <div>
                   <button type="submit" class="btn btn-secondary w-100">{{$form['regin']}}</button>
               </div>

        </div>

            @error('errorRegister')
            <p class="text-danger">{{$message}}</p>
            @enderror
        </form>
    </div>
</div>
@endsection()
@section('scripts')
    <script>
        async function updateCaptcha(route){
            let response = await fetch(route);
            let data = await response.json();
            return data['captcha'];
        }

        document.querySelector('#reload').addEventListener('click', async (e)=>{
           e.preventDefault();
           let data= await updateCaptcha(`{{route('register.reload')}}`);
           document.querySelector('#captcha-span').innerHTML=data;
        });
    </script>
@endsection
