@extends('layouts.admin')


@section("title","Главная")
@section("content")
<div><a class="btn btn-outline-info" href="{{route('admin.save.post')}}">Сохранить посты</a></div>
<div class="mt-2">
<ul class="list-group" id="list">
@if($posts->count()>0)
    @foreach($posts as $post)

        <li class="list-group-item"><div class="d-flex justify-content-between">
             <div class="d-flex">
                  <p>{{$post->title}} : {{$post->country->flag}}</p>
             </div>
             <div class="d-flex gap-3 justify-content-between">
             <a href="{{route($post->topic->id==1?'character':'episode',$post)}}"  class="btn btn-primary">Подробно</a>
             <a href="{{route('admin.post.edit',$post)}}"  class="btn btn-secondary">Редактировать</a>
             <div>
            <form action="{{route('admin.post.destroy',$post->id)}}" method="post">
                @csrf
                @method('DELETE')
                <button class="btn btn-danger">Удалить</button>
            </form>
            </div>
            </div>
         </div></li>
        @endforeach
@else
<li class="list-group-item"><div class="d-flex justify-content-between">
             <div class="d-flex">
                  <p>Список статей пуст по этой категории</p>
             </div>
             <a href="{{route('admin.post.add')}}" id='basket' class="btn btn-info">Добавить</a>
         </div></li>
@endif
    </ul>
</div>
@endsection
