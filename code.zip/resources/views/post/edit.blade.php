@extends('layouts.app')


@section("title","Главная")
@section("content")
<div class="card mb-3 mt-5 p-5">
@include("inc.error")

        <form action="{{route('admin.post.update',$post)}}" method="post" enctype="multipart/form-data">
            @csrf
            @method('PATCH')
            <div class="input-group mb-4">
                <span class="input-group-text" id="inputGroup-sizing-default">Название статьи</span>
                <input type="text" name="title" class="form-control" value="{{$post->title}}" aria-label="Sizing example input"
                       aria-describedby="inputGroup-sizing-default" >
            </div>

            <div class="input-group mb-4">
                <span class="input-group-text" id="inputGroup-sizing-default">Категории</span>
                <select class="form-select" name="topic">
                    <option value="{{$topics->id}}">{{$topics->topic}}</option>
                </select>
            </div>

            @error('name')
            <p class="text-danger">{{$message}}</p>
            @enderror

            <div class="form-floating mt-4">
                <textarea name="article" class="form-control" placeholder="Leave a comment here"
                          id="floatingTextarea" style="height: 180px; resize: none;" >{{$post->article}}</textarea>
                <label for="floatingTextarea">Карточка</label>
            </div>

            <div class="input-group mt-4">
                <span class="input-group-text" id="inputGroup-sizing-default">Актёр / Режиссер</span>
                <input type="text" name="by" class="form-control" value="{{$post->made_by}}" aria-label="Sizing example input"
                       aria-describedby="inputGroup-sizing-default" >
            </div>

            <div class="form-floating mt-4">
                <textarea name="description" class="form-control" placeholder="Leave a comment here"
                          id="floatingTextarea" style="height: 180px; resize: none;" >{{$post->description}}</textarea>
                <label for="floatingTextarea">Описание</label>
            </div>


            <div class="form-floating mt-4">
                <textarea name="content" class="form-control" placeholder="Leave a comment here"
                          id="floatingTextarea" style="height: 180px; resize: none;" >{{$post->content}}</textarea>
                <label for="floatingTextarea">Текст статьи</label>
            </div>

            <div class="form-floating mt-4">
                <textarea name="facts" class="form-control" placeholder="Leave a comment here"
                          id="floatingTextarea" style="height: 180px; resize: none;" >{{$post->facts}}</textarea>
                <label for="floatingTextarea">Интерестные факты</label>
            </div>

            @if(!empty($images))
            <div class="mt-4 d-flex justify-content-around flex-wrap">
                @foreach($images as $image)
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="deleteImage[]" value="{{$image->image}}" id="flexCheckDefault">
                    <label class="form-check-label" for="flexCheckDefault">
                    <abbr title="Удалить?" class="initialism"><img src="{{asset($image->image_full)}}" alt="{{$image->type}}" height="120" width="120"/></abbr>
                     </label>
                </div>


                @endforeach
            </div>
            @endif


            <div class="input-group mb-3 mt-4">
                <input type="file" name="images[]" class="form-control" id="inputGroupFile02" multiple accept="image/jpeg,image/png,image/gif">
                <label class="input-group-text" for="inputGroupFile02">Загрузить 📉</label>
            </div>

            <div class="d-flex justify-content-around " id="image"></div>


            @if(!empty($videos))
            <div class="mt-4 d-flex justify-content-around flex-wrap">
                @foreach($videos as $video)
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="deleteVideo[]" value="{{$video->image}}" id="flexCheckDefault">
                    <label class="form-check-label" for="flexCheckDefault">
                    <abbr title="Удалить?" class="initialism">{{$video->image}}</abbr>
                     </label>
                </div>


                @endforeach
            </div>
            @endif

            <div class="input-group mb-3 mt-4">
              <input type="file" name="video[]" class="form-control" id="inputGroupFile03" multiple accept="video/mp4">
               <label class="input-group-text" for="inputGroupFile03">Загрузить 📹</label>
           </div>





            <div class="input-group mb-3 mt-4">
                <label class="input-group-text" for="inputData">Дата</label>
                <input class="form-control" type="text" name="post-date" value="{{date('d.m.Y')}}"
                       aria-label="readonly input example" readonly id="inputData">
            </div>

            <div class="input-group mb-4">
                <span class="input-group-text" id="inputGroup-sizing-default">Страна</span>
                <select class="form-select mr-sm-2" name="country">
                    <option value="{{$country->id}}">{{$country->flag}}</option>
                </select>
            </div>


            <button name="post-button" class="btn btn-primary btn-lg">Отправить</button>
        </form>
    </div>
@endsection()


