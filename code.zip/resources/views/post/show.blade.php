@extends('layouts.app')

@section("title","Главная")
@section("content")
<div class="card bg-dark text-white mb-3 mt-5 p-5">
    <div>
        <h3>{{$post->title}}</h3>
        <hr>
    </div>
    <div>
        <div>
            {!! $post->content !!}
        </div>
        <hr>
        <div>
            Количество лайков {{$likes->likes}}
        </div>
    </div>
    <div>
        <div class="d-flex justify-content-around">
        @if(!empty($contents))
            @foreach($contents as $content)
                @if($content->type=="image")
                <div><img src="{{$content->image_full}}" height="320" width="280"/></div>
                @endif

            @endforeach

            
        @endif

        </div>
        <div class="text-center">
        @if(!empty($contents))
        @foreach($contents as $content)
                @if($content->type=="video")
                <div><video width="320" height="240" controls="controls"><source src="{{$content->image_full}}" type='video/mp4'></video></div>
                @endif

            @endforeach
        @endif
        </div>
    </div>
    </div>
@endsection()
