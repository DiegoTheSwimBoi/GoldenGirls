@extends('layouts.app')


@section("title",'')


@section("content")
    <div class="container-body mt-5">
        @include('inc.menu')
        <div class="row container mb-5">
            <div class="col-1"></div>
            <div class="col-md-10 mt-5 mb-5">
                <form>
                    <div class="input-group mb-4 w-100">
                        <input type="text" name="search" class="form-control w-75" value="{{request('search')}}">
                        <button class="btn btn-secondary search"></button>
                    </div>
                </form>
            </div>
            <div class="col-md-1 mt-5 mb-5">
                <a href="{{route('welcome')}}" class="text-decoration-none hover pink">{{$data['back']}}</a>
            </div>

<div class="col-md-9 mt-5 mb-5">
    <div class="row gap-3">
        @foreach($posts as $post)
            <div class="card border-secondary border-1 col-sm-3 " style="width: 18rem; background-color: rgb(39, 35, 35);">
                <img class="card-img-top" src="{{$post->images[0]->image_full}}" alt="{{$post->title}}">
                <div class="card-body">
                    <a href="{{route($name,$post)}}" class="text-decoration-none hover pink">{{$post->title}}</a>
                </div>
            </div>
        @endforeach
        
        <div class="mt-5">{{$posts->onEachSide(1)->links()}}</div>

    </div>
</div>
            <div class="col-md-3">
                <div class="card col-3 border-secondary border-3" style="width: 18rem; background-color: rgb(39, 35, 35);">
                    <div class="card-body text-center">
                        <h3 class="text-white">{{$data['new_posts']}}</h3>
                        @if($news!==null)
                            @foreach($news as $new_post)
                                <div class="mt-3"><a href="{{route($new_post->topic->id==1?'character':'episode',$new_post)}}" class="text-decoration-none hover pink">{{$new_post->title}}</a></div>
                            @endforeach
                        @endif
                    </div>
                </div>
            </div>

        </div>

        <div class="text-white">@include('inc.footer')</div>
    </div>

@endsection()
